# DEVAI Chat

Interface de chat para modelo de IA local no Termux, empacotada como APK Android via Capacitor.

## Compilar pelo GitHub

1. Extraia o zip e envie o conteúdo para a raiz de um repositório no GitHub.
2. Vá em Actions e execute "Build Android APK" (ou faça push na main).
3. Ao terminar, baixe o artefato "devai-chat-apk" e instale o APK no Android.

## Conectar ao Termux

Em Configurações, ajuste endereço, porta, endpoint, modelo, temperatura, limite de tokens e timeout, depois use "Testar conexão".

- O endpoint padrão é `/v1/chat/completions` no formato de requisição JSON com `stream: true`.
- As respostas aceitas são SSE (`data: {...}`) no formato de delta de chat, ou NDJSON com `message.content`, `response` ou `content`.
- O servidor precisa aceitar requisições do WebView do app, então habilite CORS (por exemplo `Access-Control-Allow-Origin: *`) e responda ao preflight `OPTIONS`.

## Desenvolvimento local

```
npm install
npm run dev
```
