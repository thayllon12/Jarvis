import { useCallback, useEffect, useRef, useState } from 'react';
import { Menu } from 'lucide-react';
import Sidebar from './components/Sidebar.jsx';
import Chat from './components/Chat.jsx';
import Settings from './components/Settings.jsx';
import StatusPill from './components/StatusPill.jsx';
import { loadConversations, saveConversations, loadConfig, saveConfig } from './lib/storage.js';
import { streamChat, testConnection } from './lib/api.js';
import { uid, makeTitle } from './lib/util.js';

const CONTINUE_PROMPT = 'Continue exatamente de onde parou, sem repetir o que já foi escrito.';

const toApi = msgs => msgs.map(({ role, content }) => ({ role, content }));

export default function App() {
  const [conversations, setConversations] = useState(loadConversations);
  const [activeId, setActiveId] = useState(null);
  const [config, setConfig] = useState(loadConfig);
  const [status, setStatus] = useState('checking');
  const [generatingId, setGeneratingId] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const abortRef = useRef(null);

  const active = conversations.find(c => c.id === activeId) ?? null;
  const isGenerating = generatingId !== null;

  useEffect(() => {
    const t = setTimeout(() => saveConversations(conversations), 300);
    return () => clearTimeout(t);
  }, [conversations]);

  useEffect(() => { saveConfig(config); }, [config]);

  const checkConnection = useCallback(async cfg => {
    setStatus('checking');
    const r = await testConnection(cfg);
    setStatus(r.ok ? 'connected' : 'disconnected');
    return r;
  }, []);

  useEffect(() => { checkConnection(config); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const patchConv = (id, fn) =>
    setConversations(prev => prev.map(c => (c.id === id ? { ...c, ...fn(c), updatedAt: Date.now() } : c)));

  const patchMessage = (convId, msgId, fn) =>
    patchConv(convId, c => ({
      messages: c.messages.map(m => (m.id === msgId ? { ...m, ...fn(m) } : m))
    }));

  const generate = async (convId, history, assistantId) => {
    const controller = new AbortController();
    abortRef.current = controller;
    setGeneratingId(assistantId);
    setStatus('generating');
    try {
      for await (const chunk of streamChat({ config, messages: history, signal: controller.signal })) {
        patchMessage(convId, assistantId, m => ({ content: m.content + chunk }));
      }
      setStatus('connected');
    } catch (err) {
      if (err.name === 'AbortError') {
        setStatus('connected');
      } else {
        patchMessage(convId, assistantId, () => ({ error: err.message }));
        setStatus(err.message.includes('conectar') ? 'disconnected' : 'connected');
      }
    } finally {
      abortRef.current = null;
      setGeneratingId(null);
    }
  };

  const send = rawText => {
    const text = rawText.trim();
    if (!text || isGenerating) return;
    const userMsg = { id: uid(), role: 'user', content: text };
    const asst = { id: uid(), role: 'assistant', content: '', error: null };

    if (!active) {
      const convId = uid();
      setConversations(prev => [{
        id: convId,
        title: makeTitle(text),
        pinned: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [userMsg, asst]
      }, ...prev]);
      setActiveId(convId);
      generate(convId, toApi([userMsg]), asst.id);
    } else {
      patchConv(active.id, () => ({ messages: [...active.messages, userMsg, asst] }));
      generate(active.id, toApi([...active.messages, userMsg]), asst.id);
    }
  };

  const regenerate = msgId => {
    if (!active || isGenerating) return;
    const idx = active.messages.findIndex(m => m.id === msgId);
    if (idx < 1) return;
    patchMessage(active.id, msgId, () => ({ content: '', error: null }));
    generate(active.id, toApi(active.messages.slice(0, idx)), msgId);
  };

  const continueReply = msgId => {
    if (!active || isGenerating) return;
    const idx = active.messages.findIndex(m => m.id === msgId);
    if (idx < 0) return;
    const history = [
      ...toApi(active.messages.slice(0, idx + 1)),
      { role: 'user', content: CONTINUE_PROMPT }
    ];
    patchMessage(active.id, msgId, () => ({ error: null }));
    generate(active.id, history, msgId);
  };

  const stop = () => abortRef.current?.abort();

  const rename = (id, title) => patchConv(id, () => ({ title }));

  const remove = id => {
    if (generatingId && active?.id === id) stop();
    setConversations(prev => prev.filter(c => c.id !== id));
    if (activeId === id) setActiveId(null);
  };

  const togglePin = id => patchConv(id, c => ({ pinned: !c.pinned }));

  const clearAll = () => {
    stop();
    setConversations([]);
    setActiveId(null);
  };

  const newChat = () => { setActiveId(null); setSidebarOpen(false); };
  const select = id => { setActiveId(id); setSidebarOpen(false); };

  return (
    <div className="app">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onNew={newChat}
        onSelect={select}
        onRename={rename}
        onDelete={remove}
        onTogglePin={togglePin}
        onOpenSettings={() => { setSettingsOpen(true); setSidebarOpen(false); }}
      />

      <main className="main">
        <header className="topbar">
          <button className="icon-btn mobile-only" aria-label="Abrir menu" onClick={() => setSidebarOpen(true)}>
            <Menu size={20} />
          </button>
          <span className="topbar-title">{active?.title ?? 'Nova conversa'}</span>
          <StatusPill status={status} />
        </header>

        <Chat
          conversation={active}
          status={status}
          isGenerating={isGenerating}
          generatingId={generatingId}
          onSend={send}
          onStop={stop}
          onRegenerate={regenerate}
          onContinue={continueReply}
        />
      </main>

      {settingsOpen && (
        <Settings
          config={config}
          status={status}
          conversationCount={conversations.length}
          onSave={setConfig}
          onTest={checkConnection}
          onClearHistory={clearAll}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}
