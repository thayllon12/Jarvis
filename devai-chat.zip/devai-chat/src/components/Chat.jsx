import { useEffect, useRef, useState } from 'react';
import { ArrowUp, Square, Paperclip, Copy, Check, RotateCcw, ArrowRight, Sparkles, AlertTriangle } from 'lucide-react';
import Markdown from './Markdown.jsx';
import StatusPill from './StatusPill.jsx';

const SUGGESTIONS = [
  'Explique o que é um Transformer de forma simples',
  'Escreva uma função em Python que ordena uma lista de dicionários',
  'Crie um plano de estudos de 4 semanas para C++',
  'Revise este texto e sugira melhorias'
];

const CONTINUE_LABEL = 'Continuar';

export default function Chat({
  conversation, status, isGenerating, generatingId,
  onSend, onStop, onRegenerate, onContinue
}) {
  const [input, setInput] = useState('');
  const scrollRef = useRef(null);
  const stick = useRef(true);
  const taRef = useRef(null);
  const fileRef = useRef(null);
  const messages = conversation?.messages ?? [];
  const lastIdx = messages.length - 1;

  useEffect(() => {
    const el = scrollRef.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [messages]);

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = `${Math.min(ta.scrollHeight, 200)}px`;
  }, [input]);

  const onScroll = () => {
    const el = scrollRef.current;
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  };

  const submit = () => {
    if (!input.trim() || isGenerating) return;
    stick.current = true;
    onSend(input);
    setInput('');
  };

  const onKeyDown = e => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  const onFile = async e => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 300 * 1024) {
      window.alert('Arquivo muito grande (limite de 300 KB).');
      return;
    }
    const text = await file.text();
    setInput(prev => `${prev}${prev ? '\n\n' : ''}Arquivo: ${file.name}\n\`\`\`\n${text}\n\`\`\``);
  };

  return (
    <section className="chat">
      {messages.length === 0 ? (
        <Welcome status={status} onPick={onSend} />
      ) : (
        <div className="messages" ref={scrollRef} onScroll={onScroll}>
          <div className="messages-inner">
            {messages.map((m, i) => (
              <Message
                key={m.id}
                message={m}
                busy={isGenerating && m.id === generatingId}
                canRegenerate={i === lastIdx && m.role === 'assistant' && !isGenerating}
                canContinue={i === lastIdx && m.role === 'assistant' && !isGenerating && !!m.content && !m.error}
                onRegenerate={onRegenerate}
                onContinue={onContinue}
              />
            ))}
          </div>
        </div>
      )}

      <div className="composer-wrap">
        <div className="composer">
          <textarea
            ref={taRef}
            rows={1}
            value={input}
            placeholder="Pergunte alguma coisa ao DEVAI"
            onChange={e => setInput(e.target.value)}
            onKeyDown={onKeyDown}
          />
          <div className="composer-row">
            <button className="icon-btn" aria-label="Anexar arquivo" onClick={() => fileRef.current?.click()}>
              <Paperclip size={18} />
            </button>
            <input
              ref={fileRef}
              type="file"
              hidden
              accept=".txt,.md,.py,.js,.jsx,.ts,.tsx,.json,.html,.css,.cpp,.h,.c,.cs,.lua,.csv,.xml,.yml,.yaml"
              onChange={onFile}
            />
            {isGenerating ? (
              <button className="send stop" aria-label="Interromper geração" onClick={onStop}>
                <Square size={14} fill="currentColor" />
              </button>
            ) : (
              <button className="send" aria-label="Enviar" disabled={!input.trim()} onClick={submit}>
                <ArrowUp size={18} />
              </button>
            )}
          </div>
        </div>
        <p className="hint">Enter envia · Shift + Enter quebra a linha · Modelo executado localmente</p>
      </div>
    </section>
  );
}

function Welcome({ status, onPick }) {
  return (
    <div className="welcome">
      <div className="logo-big"><Sparkles size={26} /></div>
      <h1>DEVAI</h1>
      <p>Seu assistente de IA executado diretamente no seu dispositivo. Como posso ajudar hoje?</p>
      <StatusPill status={status} />
      <div className="suggestions">
        {SUGGESTIONS.map(s => <button key={s} onClick={() => onPick(s)}>{s}</button>)}
      </div>
    </div>
  );
}

function Message({ message, busy, canRegenerate, canContinue, onRegenerate, onContinue }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try { await navigator.clipboard.writeText(message.content); } catch {}
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  if (message.role === 'user') {
    return (
      <div className="msg user">
        <div className="bubble">{message.content}</div>
      </div>
    );
  }

  const empty = !message.content;

  return (
    <div className="msg assistant">
      <div className="avatar"><Sparkles size={15} /></div>
      <div className="body">
        {empty && !message.error
          ? <div className="typing"><span /><span /><span /></div>
          : <Markdown>{message.content}</Markdown>}

        {message.error && (
          <div className="error"><AlertTriangle size={15} />{message.error}</div>
        )}

        {!busy && (
          <div className="msg-actions">
            {!empty && (
              <button className="icon-btn" title="Copiar" onClick={copy}>
                {copied ? <Check size={15} /> : <Copy size={15} />}
              </button>
            )}
            {canRegenerate && (
              <button className="icon-btn" title="Regenerar" onClick={() => onRegenerate(message.id)}>
                <RotateCcw size={15} />
              </button>
            )}
            {canContinue && (
              <button className="icon-btn" title={CONTINUE_LABEL} onClick={() => onContinue(message.id)}>
                <ArrowRight size={15} />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
