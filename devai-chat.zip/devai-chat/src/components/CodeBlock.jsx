import { useEffect, useState } from 'react';
import { codeToHtml } from 'shiki';
import { Copy, Check, ChevronDown, ChevronUp, Code2 } from 'lucide-react';

const ALIASES = {
  js: 'javascript', ts: 'typescript', py: 'python', 'c++': 'cpp', cc: 'cpp',
  cs: 'csharp', 'c#': 'csharp', sh: 'bash', shell: 'bash', yml: 'yaml',
  luau: 'lua', md: 'markdown', text: 'plaintext', txt: 'plaintext'
};

const LABELS = {
  javascript: 'JavaScript', typescript: 'TypeScript', python: 'Python', cpp: 'C++',
  csharp: 'C#', lua: 'Lua', json: 'JSON', html: 'HTML', css: 'CSS', bash: 'Bash',
  markdown: 'Markdown', yaml: 'YAML', plaintext: 'Texto'
};

export default function CodeBlock({ lang = '', code }) {
  const raw = (lang || '').toLowerCase();
  const norm = ALIASES[raw] ?? (raw || 'plaintext');
  const [html, setHtml] = useState('');
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const long = code.split('\n').length > 18;

  useEffect(() => {
    let alive = true;
    codeToHtml(code, { lang: norm, theme: 'github-dark' })
      .catch(() => codeToHtml(code, { lang: 'plaintext', theme: 'github-dark' }))
      .then(h => { if (alive) setHtml(h); })
      .catch(() => {});
    return () => { alive = false; };
  }, [code, norm]);

  const copy = async () => {
    try { await navigator.clipboard.writeText(code); } catch {}
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const label = LABELS[norm] ?? (raw ? raw.toUpperCase() : 'Código');

  return (
    <div className="codeblock">
      <div className="cb-head">
        <div className="cb-lang"><Code2 size={14} />{label}</div>
        <div className="cb-actions">
          {long && (
            <button onClick={() => setExpanded(e => !e)}>
              {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              {expanded ? 'Recolher' : 'Expandir'}
            </button>
          )}
          <button onClick={copy}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? 'Copiado' : 'Copiar'}
          </button>
        </div>
      </div>
      <div className={`cb-body ${long && !expanded ? 'collapsed' : ''}`}>
        {html
          ? <div className="cb-code" dangerouslySetInnerHTML={{ __html: html }} />
          : <pre className="cb-plain"><code>{code}</code></pre>}
      </div>
    </div>
  );
}
