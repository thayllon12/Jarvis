import { Wifi, WifiOff, Loader } from 'lucide-react';

const MAP = {
  checking: { label: 'Verificando', cls: 'pending', Icon: Loader },
  connected: { label: 'Modelo conectado', cls: 'ok', Icon: Wifi },
  disconnected: { label: 'Desconectado', cls: 'bad', Icon: WifiOff },
  generating: { label: 'Gerando resposta', cls: 'busy', Icon: Loader }
};

export default function StatusPill({ status }) {
  const { label, cls, Icon } = MAP[status] ?? MAP.checking;
  const spin = cls === 'pending' || cls === 'busy';
  return (
    <span className={`pill ${cls}`}>
      <Icon size={13} className={spin ? 'spin' : ''} />
      {label}
    </span>
  );
}
