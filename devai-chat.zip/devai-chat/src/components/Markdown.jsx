import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import CodeBlock from './CodeBlock.jsx';

export default function Markdown({ children }) {
  return (
    <div className="md">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          pre({ children }) {
            return <>{children}</>;
          },
          code({ node, className, children, ...props }) {
            const text = String(children).replace(/\n$/, '');
            const lang = /language-([\w+#-]+)/.exec(className || '')?.[1];
            const isBlock = !!className || text.includes('\n');
            if (!isBlock) {
              return <code className="inline-code" {...props}>{children}</code>;
            }
            return <CodeBlock lang={lang} code={text} />;
          },
          a({ href, children }) {
            return <a href={href} target="_blank" rel="noopener noreferrer">{children}</a>;
          },
          table({ children }) {
            return <div className="table-wrap"><table>{children}</table></div>;
          }
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
