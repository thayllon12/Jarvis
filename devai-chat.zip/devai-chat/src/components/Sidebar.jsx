import { useMemo, useState } from 'react';
import { Plus, Search, Pin, PinOff, Pencil, Trash2, Settings, Sparkles, X, User } from 'lucide-react';

export default function Sidebar({
  conversations, activeId, open, onClose, onNew, onSelect,
  onRename, onDelete, onTogglePin, onOpenSettings
}) {
  const [query, setQuery] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [draft, setDraft] = useState('');

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return conversations
      .filter(c => c.title.toLowerCase().includes(q))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }, [conversations, query]);

  const pinned = list.filter(c => c.pinned);
  const recent = list.filter(c => !c.pinned);

  const startRename = c => { setEditingId(c.id); setDraft(c.title); };
  const commit = id => {
    const t = draft.trim();
    if (t) onRename(id, t);
    setEditingId(null);
  };
  const confirmDelete = c => {
    if (window.confirm(`Excluir "${c.title}"?`)) onDelete(c.id);
  };

  const item = c => (
    <div key={c.id} className={`conv ${c.id === activeId ? 'active' : ''}`}>
      {editingId === c.id ? (
        <input
          autoFocus
          value={draft}
          onChange={e => setDraft(e.target.value)}
          onBlur={() => commit(c.id)}
          onKeyDown={e => {
            if (e.key === 'Enter') commit(c.id);
            if (e.key === 'Escape') setEditingId(null);
          }}
        />
      ) : (
        <>
          <button className="conv-title" onClick={() => onSelect(c.id)}>{c.title}</button>
          <div className="conv-actions">
            <button className="icon-btn" title={c.pinned ? 'Desafixar' : 'Fixar'} onClick={() => onTogglePin(c.id)}>
              {c.pinned ? <PinOff size={14} /> : <Pin size={14} />}
            </button>
            <button className="icon-btn" title="Renomear" onClick={() => startRename(c)}><Pencil size={14} /></button>
            <button className="icon-btn" title="Excluir" onClick={() => confirmDelete(c)}><Trash2 size={14} /></button>
          </div>
        </>
      )}
    </div>
  );

  return (
    <>
      <div className={`overlay ${open ? 'show' : ''}`} onClick={onClose} />
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sidebar-head">
          <div className="brand">
            <span className="brand-mark"><Sparkles size={16} /></span>
            DEVAI
          </div>
          <button className="icon-btn mobile-only" aria-label="Fechar menu" onClick={onClose}><X size={18} /></button>
        </div>

        <button className="btn-new" onClick={onNew}><Plus size={16} /> Nova conversa</button>

        <label className="search">
          <Search size={15} />
          <input placeholder="Pesquisar conversas" value={query} onChange={e => setQuery(e.target.value)} />
        </label>

        <div className="conv-list">
          {pinned.length > 0 && (
            <>
              <div className="group-title">Fixadas</div>
              {pinned.map(item)}
            </>
          )}
          <div className="group-title">Recentes</div>
          {recent.length === 0 && <p className="empty">Nenhuma conversa</p>}
          {recent.map(item)}
        </div>

        <div className="sidebar-foot">
          <button className="menu-item" onClick={onOpenSettings}><Settings size={16} /> Configurações</button>
          <div className="profile">
            <span className="avatar-sm"><User size={15} /></span>
            <div>
              <div className="profile-name">Usuário local</div>
              <div className="profile-sub">Este dispositivo</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
