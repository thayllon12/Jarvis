import { useState } from 'react';
import { X, Check, Loader, Trash2 } from 'lucide-react';
import StatusPill from './StatusPill.jsx';

const NUMERIC = ['port', 'temperature', 'maxTokens', 'timeoutSec'];

export default function Settings({ config, status, conversationCount, onSave, onTest, onClearHistory, onClose }) {
  const [draft, setDraft] = useState(config);
  const [result, setResult] = useState(null);
  const [testing, setTesting] = useState(false);

  const set = key => e => {
    const value = NUMERIC.includes(key) ? Number(e.target.value) : e.target.value;
    setDraft(d => ({ ...d, [key]: value }));
  };

  const test = async () => {
    setTesting(true);
    setResult(null);
    setResult(await onTest(draft));
    setTesting(false);
  };

  const save = () => { onSave(draft); onClose(); };

  const url = `${draft.host.replace(/\/+$/, '')}:${draft.port}${draft.endpoint.startsWith('/') ? '' : '/'}${draft.endpoint}`;

  return (
    <div className="overlay-modal" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-label="Configurações">
        <div className="modal-head">
          <h2>Configurações</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Fechar"><X size={18} /></button>
        </div>
        <p className="sub">Conexão com o modelo executado no Termux</p>

        <div className="section">
          <h3>Conexão</h3>
          <div className="grid2">
            <label className="field">Endereço<input value={draft.host} onChange={set('host')} /></label>
            <label className="field">Porta<input type="number" value={draft.port} onChange={set('port')} /></label>
          </div>
          <label className="field">Endpoint<input value={draft.endpoint} onChange={set('endpoint')} /></label>
          <label className="field">Modelo<input value={draft.model} placeholder="Nome do modelo (opcional)" onChange={set('model')} /></label>
          <div className="row-btns">
            <button className="btn" onClick={test} disabled={testing}>
              {testing && <Loader size={15} className="spin" />}
              Testar conexão
            </button>
            {result && (
              <span className="result" style={{ color: result.ok ? 'var(--ok)' : 'var(--bad)' }}>
                {result.ok ? <Check size={15} /> : <X size={15} />}
                {result.message}{result.ms != null && ` (${result.ms} ms)`}
              </span>
            )}
          </div>
        </div>

        <div className="section">
          <h3>Geração</h3>
          <label className="field">
            Temperatura: {Number(draft.temperature).toFixed(2)}
            <input type="range" min="0" max="2" step="0.05" value={draft.temperature} onChange={set('temperature')} />
          </label>
          <div className="grid2">
            <label className="field">Limite de tokens<input type="number" value={draft.maxTokens} onChange={set('maxTokens')} /></label>
            <label className="field">Timeout (s)<input type="number" value={draft.timeoutSec} onChange={set('timeoutSec')} /></label>
          </div>
        </div>

        <div className="section">
          <h3>Aparência</h3>
          <p className="sub" style={{ margin: 0 }}>Tema: Escuro</p>
        </div>

        <div className="section">
          <h3>Modelo</h3>
          <div className="info-row"><span>Status</span><StatusPill status={status} /></div>
          <div className="info-row"><span>Endpoint</span><code className="inline-code">{url}</code></div>
        </div>

        <div className="section">
          <h3>Histórico</h3>
          <p className="sub" style={{ margin: '0 0 10px' }}>{conversationCount} conversas salvas neste dispositivo.</p>
          <button className="btn danger" onClick={() => window.confirm('Apagar todo o histórico?') && onClearHistory()}>
            <Trash2 size={15} /> Limpar histórico
          </button>
        </div>

        <div className="row-btns end">
          <button className="btn" onClick={onClose}>Cancelar</button>
          <button className="btn primary" onClick={save}>Salvar</button>
        </div>
      </div>
    </div>
  );
}
