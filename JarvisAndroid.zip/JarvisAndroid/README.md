# JARVIS AI — Android

Assistente Android nativo (Kotlin + Jetpack Compose) com HUD futurista, Gemini, voz ElevenLabs, bolinha flutuante e compartilhamento de tela.

## Recursos
- **Bolinha flutuante:** ícone de camadas no topo liga o JARVIS fora do app. Toque para falar, segure para abrir o app, arraste para mover.
- **Compartilhamento de tela:** ícone de tela no topo. Com ele ativo, o JARVIS recebe uma imagem da tela a cada mensagem e responde sobre ela.
- **Voz ElevenLabs:** voz hwnuNyWkl9DjdTFykrN6, com fallback para a voz do Android.
- **Controle do aparelho:** o Gemini executa ações de verdade.
  - Ligações, SMS, WhatsApp com envio automático, contatos, chamadas e SMS recebidos.
  - Lanterna, volume, brilho, Não perturbe, vibração, alarme, timer, agenda.
  - Maps, música, controle de mídia, câmera, bateria, localização, notificações, área de transferência, compartilhar.
  - Ler a tela, tocar por texto, digitar, rolar, deslizar, tocar em coordenadas, voltar, início, recentes, captura de tela, bloquear.

## Permissões
Na primeira abertura o app pede as permissões padrão e abre o painel (ícone de escudo). Ative lá os acessos especiais: Acessibilidade, Notificações, Sobrepor apps, Modificar configurações, Não perturbe, Bateria, Alarmes exatos, Todos os arquivos e Localização o tempo todo.

No Android 13+, para app fora da loja: Info do app > menu ⋮ > Permitir configurações restritas, antes de ativar Acessibilidade e Notificações.

## ElevenLabs
A chave é lida de `.env.local` (`ELEVENLABS_API_KEY=`) ou da variável de ambiente no build, e fica embutida no APK. Também dá para colar a chave em Configurações no app. O `.env.local` não vai para o Git.

No GitHub, crie o secret `ELEVENLABS_API_KEY` em Settings > Secrets and variables > Actions, ou cole a chave no app.

## Compilar no GitHub
1. Envie o conteúdo desta pasta para a raiz de um repositório.
2. Actions > Build JARVIS Android APK > Run workflow.
3. Baixe o artefato JARVIS-AI-debug-apk e instale o app-debug.apk.

## Limites
- A bolinha não inicia sozinha ao ligar o celular. Abra o app e ative uma vez.
- O compartilhamento de tela pede aprovação do Android a cada sessão.
- Wi-Fi e Bluetooth abrem a tela de configurações, o Android não permite ligar por apps.
