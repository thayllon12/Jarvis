# JARVIS AI — Android

Aplicativo Android nativo em Kotlin + Jetpack Compose, com interface futurista inspirada no vídeo enviado.

## O que já funciona
- Interface responsiva com HUD circular animado e tema azul/ciano.
- Chat local e integração com a API Gemini.
- Campo para configurar e salvar a API Key e o nome do modelo.
- Reconhecimento de voz em português do Brasil usando o serviço de voz do Android.
- Respostas faladas com Text-to-Speech do Android.
- Comando local `abrir WhatsApp`, `abrir YouTube`, `abrir Instagram`, `abrir Spotify`, `abrir Chrome`, `abrir Lark Player` e `abrir configurações` (a disponibilidade depende dos apps instalados e de como aparecem no aparelho).
- Consulta local de horário com `que horas são?`.
- Workflow do GitHub Actions para compilar o APK de depuração.

## Limitações importantes
- O comando para tocar música informa a limitação e orienta abrir o player. Controlar diretamente a reprodução em qualquer player de terceiros não é uma função universal do Android; exige integração específica com cada aplicativo ou uma API compatível.
- O reconhecimento de voz depende do serviço de reconhecimento instalado/configurado no Android e pode precisar de internet.
- Para respostas inteligentes, é necessário fornecer uma chave Gemini válida. A chave é salva nas preferências privadas do aplicativo neste aparelho; não coloque uma chave pessoal em repositórios públicos.
- O app não envia mensagens automaticamente nem lê a tela. Isso exigiria fluxos adicionais com permissões explícitas, intents e/ou serviços de acessibilidade, que não fazem parte desta primeira versão.

## Como compilar no GitHub
1. Crie um repositório no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório (não envie a pasta `JarvisAndroid` dentro de outra pasta).
3. Abra **Actions** e execute **Build JARVIS Android APK** ou faça push na branch `main`/`master`.
4. Quando terminar, abra a execução e baixe o artefato **JARVIS-AI-debug-apk**.
5. Extraia o artefato e instale `app-debug.apk` no Android. Se necessário, autorize a instalação de apps dessa origem.

## Configuração da IA
1. Abra o app e toque na engrenagem.
2. Cole sua chave da API Gemini.
3. Deixe `gemini-2.0-flash` como modelo inicial ou informe um modelo disponível na sua conta/API.
4. Salve e envie uma mensagem.

## Estrutura
- `app/` — aplicativo Android.
- `.github/workflows/build.yml` — compilação automática do APK.
