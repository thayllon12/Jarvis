package com.devai.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatSession(val id: String, val title: String, val messages: List<ChatMessage>, val updated: Long)

/** Persiste o histórico de conversas em arquivo interno do app. */
object ChatStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "chats.json")

    fun load(ctx: Context): List<ChatSession> {
        val out = mutableListOf<ChatSession>()
        try {
            val arr = JSONArray(file(ctx).readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ms = o.getJSONArray("messages")
                val list = (0 until ms.length()).map { j ->
                    val m = ms.getJSONObject(j)
                    ChatMessage(m.getString("t"), m.getBoolean("u"), m.optBoolean("s"), m.optString("a").ifBlank { null })
                }
                out.add(ChatSession(o.getString("id"), o.getString("title"), list, o.getLong("updated")))
            }
        } catch (e: Exception) {
            // Sem arquivo ainda ou arquivo corrompido: começa vazio.
        }
        return out
    }

    fun save(ctx: Context, sessions: List<ChatSession>) {
        val arr = JSONArray()
        sessions.take(60).forEach { s ->
            val ms = JSONArray()
            s.messages.takeLast(200).forEach { m ->
                ms.put(JSONObject().put("t", m.text).put("u", m.fromUser).put("s", m.system).put("a", m.api ?: ""))
            }
            arr.put(JSONObject().put("id", s.id).put("title", s.title).put("updated", s.updated).put("messages", ms))
        }
        try {
            file(ctx).writeText(arr.toString())
        } catch (e: Exception) {
            // Falha de escrita não derruba o chat.
        }
    }
}
