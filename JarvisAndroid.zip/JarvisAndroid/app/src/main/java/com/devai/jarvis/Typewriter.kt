package com.devai.jarvis

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Revela a resposta à medida que o texto chega do modelo, em ritmo constante
 * (cerca de 60 atualizações por segundo). Cada caractere revelado pode disparar
 * um toque de vibração, com limite para não virar zumbido contínuo.
 */
class Typewriter(
    private val scope: CoroutineScope,
    private val onText: (String) -> Unit,
    private val onChar: () -> Unit
) {
    private var target = ""
    private var shown = 0
    private var lastBuzz = 0L
    private var job: Job? = null

    fun setTarget(full: String) {
        target = full
        if (job == null) job = scope.launch { loop() }
    }

    private suspend fun loop() {
        while (shown < target.length) {
            val pending = target.length - shown
            val step = (pending / 6).coerceIn(1, 14)
            shown = minOf(target.length, shown + step)
            onText(target.substring(0, shown))
            val now = System.currentTimeMillis()
            if (now - lastBuzz >= 40) {
                lastBuzz = now
                onChar()
            }
            delay(16)
        }
        job = null
    }

    /** Mostra o texto completo de uma vez e encerra a animação. */
    fun finish(full: String) {
        job?.cancel()
        job = null
        target = full
        shown = full.length
        onText(full)
    }

    fun cancel() {
        job?.cancel()
        job = null
    }
}
