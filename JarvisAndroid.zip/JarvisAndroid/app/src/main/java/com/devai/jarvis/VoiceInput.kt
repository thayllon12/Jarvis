package com.devai.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Captura de voz com tolerância a pausas.
 *
 * Trechos reconhecidos separados por pausas curtas são juntados numa única frase.
 * A frase só é entregue quando a pessoa fica em silêncio por PAUSE_TOLERANCE_MS.
 * Cada sessão tem um id: callbacks de sessões antigas são ignorados, então não
 * há duas capturas brigando pelo microfone.
 */
class VoiceInput(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onEnd: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var session = 0
    private var active = false
    private val buffer = StringBuilder()

    companion object {
        const val PAUSE_TOLERANCE_MS = 1800L
        const val MAX_SESSION_MS = 90_000L
    }

    private val flush = Runnable { finish(false) }
    private val timeout = Runnable { finish(false) }

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onEnd(false)
            return
        }
        Voice.stop()
        session++
        buffer.clear()
        active = true
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, MAX_SESSION_MS)
        listenOnce(session)
    }

    /** Cancela a captura sem entregar texto. */
    fun cancel() {
        if (!active) return
        session++
        active = false
        buffer.clear()
        clearTimers()
        destroyRecognizer()
        onEnd(false)
    }

    fun destroy() {
        session++
        active = false
        buffer.clear()
        clearTimers()
        destroyRecognizer()
    }

    private fun clearTimers() {
        main.removeCallbacks(flush)
        main.removeCallbacks(timeout)
    }

    private fun destroyRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun scheduleFlush() {
        main.removeCallbacks(flush)
        main.postDelayed(flush, PAUSE_TOLERANCE_MS)
    }

    private fun listenAgain(id: Int, delayMs: Long = 250L) {
        main.postDelayed({ listenOnce(id) }, delayMs)
    }

    private fun listenOnce(id: Int) {
        if (!active || id != session) return
        destroyRecognizer()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1500L)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                if (id != session) return
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!phrase.isNullOrBlank()) {
                    if (buffer.isNotEmpty()) buffer.append(' ')
                    buffer.append(phrase.trim())
                }
                // A pessoa pode continuar a frase: segue ouvindo e agenda o envio após a pausa.
                scheduleFlush()
                listenAgain(id)
            }

            override fun onError(error: Int) {
                if (id != session) return
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> finish(true)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> listenAgain(id, 700L)
                    else -> if (buffer.isNotEmpty()) scheduleFlush() else listenAgain(id, 400L)
                }
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(intent)
    }

    /** Encerra a sessão. forceEmpty descarta o que foi captado (ex.: sem permissão). */
    private fun finish(forceEmpty: Boolean) {
        clearTimers()
        val text = if (forceEmpty) "" else buffer.toString().trim()
        buffer.clear()
        active = false
        session++
        destroyRecognizer()
        if (text.isBlank()) onEnd(false)
        else {
            onEnd(true)
            onText(text)
        }
    }
}
