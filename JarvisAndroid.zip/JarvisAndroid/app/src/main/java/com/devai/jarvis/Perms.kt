package com.devai.jarvis

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

data class SpecialAccess(val title: String, val description: String, val granted: Boolean, val intent: Intent)

object Perms {
    fun runtime(): List<String> {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_PHONE_NUMBERS,
            Manifest.permission.ACTIVITY_RECOGNITION,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) {
            list += Manifest.permission.POST_NOTIFICATIONS
            list += Manifest.permission.READ_MEDIA_IMAGES
            list += Manifest.permission.READ_MEDIA_VIDEO
            list += Manifest.permission.READ_MEDIA_AUDIO
            list += Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            list += Manifest.permission.READ_EXTERNAL_STORAGE
            if (Build.VERSION.SDK_INT <= 28) list += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT >= 29) list += Manifest.permission.ACCESS_MEDIA_LOCATION
        if (Build.VERSION.SDK_INT >= 31) {
            list += Manifest.permission.BLUETOOTH_CONNECT
            list += Manifest.permission.BLUETOOTH_SCAN
        }
        return list
    }

    fun missing(ctx: Context): List<String> =
        runtime().filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }

    fun has(ctx: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    fun special(ctx: Context): List<SpecialAccess> {
        val pkg = Uri.parse("package:${ctx.packageName}")
        val list = mutableListOf<SpecialAccess>()

        val accessibilityId = ComponentName(ctx, JarvisAccessibilityService::class.java).flattenToString()
        val enabledServices = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        list += SpecialAccess(
            "Acessibilidade",
            "Voltar, início, recentes, notificações, captura de tela e bloqueio",
            enabledServices.split(':').any { it.equals(accessibilityId, true) },
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        )

        list += SpecialAccess(
            "Acesso a notificações",
            "Ler as notificações recebidas",
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName),
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        )

        list += SpecialAccess(
            "Sobrepor outros apps",
            "Mostrar o JARVIS sobre outros aplicativos",
            Settings.canDrawOverlays(ctx),
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
        )

        list += SpecialAccess(
            "Modificar configurações do sistema",
            "Controlar o brilho da tela",
            Settings.System.canWrite(ctx),
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)
        )

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        list += SpecialAccess(
            "Não perturbe",
            "Ativar e desativar o modo Não perturbe",
            nm.isNotificationPolicyAccessGranted,
            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        )

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        list += SpecialAccess(
            "Ignorar otimização de bateria",
            "Manter o JARVIS ativo em segundo plano",
            pm.isIgnoringBatteryOptimizations(ctx.packageName),
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)
        )

        if (Build.VERSION.SDK_INT >= 29) {
            list += SpecialAccess(
                "Localização o tempo todo",
                "Usar a localização com o app fechado (escolha 'Permitir o tempo todo')",
                has(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION),
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
            )
        }

        if (Build.VERSION.SDK_INT >= 31) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            list += SpecialAccess(
                "Alarmes exatos",
                "Agendar alarmes e lembretes no horário certo",
                am.canScheduleExactAlarms(),
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg)
            )
        }

        if (Build.VERSION.SDK_INT >= 30) {
            list += SpecialAccess(
                "Acesso a todos os arquivos",
                "Ler e gravar arquivos em todo o armazenamento",
                Environment.isExternalStorageManager(),
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg)
            )
        }

        return list
    }

    fun open(ctx: Context, intent: Intent) {
        try {
            ctx.startActivity(Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
