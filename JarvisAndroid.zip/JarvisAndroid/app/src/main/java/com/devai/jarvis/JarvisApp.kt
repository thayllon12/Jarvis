package com.devai.jarvis

import android.app.Application
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registra falhas não tratadas em crash.log (dentro do app) antes de o app fechar. */
class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                val log = File(filesDir, "crash.log")
                if (log.length() > 300_000) log.writeText("")
                log.appendText("\n[$stamp] thread=${thread.name}\n${error.stackTraceToString()}\n")
            } catch (_: Exception) {
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
