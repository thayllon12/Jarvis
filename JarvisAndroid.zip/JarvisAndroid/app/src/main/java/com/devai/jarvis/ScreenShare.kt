package com.devai.jarvis

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.ByteArrayOutputStream

object ScreenShare {
    @Volatile
    var latest: Bitmap? = null

    var active by mutableStateOf(false)

    fun request(ctx: Context, on: Boolean): String {
        return if (on) {
            ctx.startActivity(Intent(ctx, ScreenSharePermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Aprove o compartilhamento de tela na janela do Android."
        } else {
            ctx.startService(Intent(ctx, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_STOP))
            "Compartilhamento de tela encerrado."
        }
    }

    fun frameBase64(maxWidth: Int = 1024): String? {
        val bmp = latest ?: return null
        val scale = if (bmp.width > maxWidth) maxWidth.toFloat() / bmp.width else 1f
        val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val stream = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 65, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
}
