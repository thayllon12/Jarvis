package com.devai.jarvis

import android.content.Context
import android.accessibilityservice.AccessibilityService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * Agente de autonomia: observa a tela (árvore de acessibilidade + imagem da
 * captura, se ativa), pede ao Gemini o próximo passo em JSON, executa e repete
 * até concluir, pedir confirmação ou atingir o limite de passos.
 */
object Agent {
    @Volatile
    var stopRequested = false
    var running by mutableStateOf(false)
    var lastThought by mutableStateOf("")

    private const val MAX_STEPS = 25

    // Só bloqueia ações realmente sensíveis: dinheiro, senhas e exclusão de conta.
    private val sensitive = Regex(
        "senha|password|pix|pagar|pagamento|comprar|compra|cartão|cartao|cvv|transferir|transfer[êe]ncia|excluir conta|apagar conta|deletar conta|assinar",
        RegexOption.IGNORE_CASE
    )

    private const val AGENT_PROMPT = """Você controla um celular Android como uma pessoa faria, um passo por vez, com base na lista de elementos visíveis e, quando existir, na imagem da tela.
Responda APENAS um objeto JSON com as chaves: thought (frase curta do que está fazendo), action, index, text, direction, answer.
action pode ser:
- tap: toca no elemento de índice index
- type: digita text no campo de índice index (ou no campo focado se index for -1)
- scroll: direction up ou down
- swipe: direction up, down, left ou right
- back: botão voltar
- home: tela inicial
- open_app: abre o app de nome text
- wait: espera a tela carregar
- done: objetivo cumprido; answer é a resposta final em português para o usuário
- ask: falta uma informação ou confirmação sensível; answer é a pergunta
Regras: um único passo por vez; use somente os índices da lista; se a tela não mudou depois de uma ação, tente outro caminho; nunca invente senhas, dados de pagamento ou dados pessoais que o usuário não forneceu."""

    suspend fun run(ctx: Context, goal: String, key: String, model: String): String {
        val service = JarvisAccessibilityService.instance
            ?: return "Ative o serviço de Acessibilidade do JARVIS nas configurações para eu controlar a tela."
        stopRequested = false
        running = true
        val log = StringBuilder()
        try {
            for (step in 1..MAX_STEPS) {
                if (stopRequested) return "Execução interrompida por você."
                val els = service.snapshot()
                val img = if (ScreenShare.active) ScreenShare.frameBase64(720) else null
                val screen = els.joinToString("\n") { "[${it.idx}] ${it.kind}: ${it.label.ifBlank { "(sem texto)" }}" }
                val prompt = "OBJETIVO: $goal\nPASSO $step de $MAX_STEPS | app atual: ${service.currentPackage()}\n" +
                    "JÁ FEITO:\n${log.takeLast(1500)}\nELEMENTOS VISÍVEIS:\n${screen.ifBlank { "(nenhum)" }}"
                val raw = Brain.callAny(ctx, listOf(ChatMessage(prompt, true)), key, model, img, AGENT_PROMPT, json = true)
                val d = parse(raw)
                if (d == null) {
                    log.append("$step. resposta inválida do modelo\n")
                    delay(800)
                    continue
                }
                val action = d.optString("action")
                val thought = d.optString("thought")
                lastThought = thought
                log.append("$step. $action ${d.optString("text")} — $thought\n")

                when (action) {
                    "done" -> return d.optString("answer").ifBlank { "Pronto." }
                    "ask" -> return d.optString("answer").ifBlank { "Preciso da sua confirmação para continuar." }
                    "tap" -> {
                        val el = els.find { it.idx == d.optInt("index", -1) }
                        if (el == null) {
                            log.append("elemento não encontrado\n")
                        } else if (sensitive.containsMatchIn(el.label)) {
                            return "Parei antes de tocar em \"${el.label}\" porque parece uma ação sensível. Confirme se devo continuar."
                        } else {
                            service.tapElement(el)
                        }
                    }
                    "type" -> {
                        val el = els.find { it.idx == d.optInt("index", -1) }
                        if (el != null && sensitive.containsMatchIn(el.label)) {
                            return "Esse campo parece sensível (\"${el.label}\"). Prefiro que você preencha este passo."
                        }
                        service.typeInto(el, d.optString("text"))
                    }
                    "scroll" -> service.scroll(d.optString("direction") != "up")
                    "swipe" -> service.swipeDir(d.optString("direction"))
                    "back" -> JarvisAccessibilityService.perform(AccessibilityService.GLOBAL_ACTION_BACK)
                    "home" -> JarvisAccessibilityService.perform(AccessibilityService.GLOBAL_ACTION_HOME)
                    "open_app" -> Actions(ctx).run("open_app", d.optString("text"))
                    "wait" -> {}
                    else -> log.append("ação desconhecida: $action\n")
                }
                delay(1200)
            }
            return "Parei após $MAX_STEPS passos sem concluir. Último passo: $lastThought"
        } finally {
            running = false
        }
    }

    private fun parse(raw: String): JSONObject? {
        val s = raw.replace("```json", "").replace("```", "").trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(s.substring(a, b + 1)) } catch (e: Exception) { null }
    }
}
