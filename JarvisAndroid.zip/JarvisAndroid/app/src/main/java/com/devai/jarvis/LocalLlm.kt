package com.devai.jarvis

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente para um servidor local compatível com a API OpenAI
 * (ex.: llama-server do llama.cpp rodando no Termux, em 127.0.0.1:8080).
 */
object LocalLlm {
    private fun endpoint(ctx: Context): URL = URL(Config.localUrl(ctx).trimEnd('/') + "/chat/completions")

    private fun body(ctx: Context, history: List<ChatMessage>, system: String, stream: Boolean, json: Boolean): JSONObject {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.forEach { m ->
            msgs.put(JSONObject().put("role", if (m.fromUser) "user" else "assistant").put("content", m.api ?: m.text))
        }
        val b = JSONObject()
            .put("model", Config.localModel(ctx))
            .put("messages", msgs)
            .put("stream", stream)
            .put("temperature", 0.6)
            .put("max_tokens", if (json) 600 else 1024)
        if (json) b.put("response_format", JSONObject().put("type", "json_object"))
        return b
    }

    private fun open(ctx: Context, body: JSONObject): HttpURLConnection {
        val c = endpoint(ctx).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 180000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        Config.localKey(ctx).takeIf { it.isNotBlank() }?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return c
    }

    private fun unreachable(ctx: Context, e: IOException) = IllegalStateException(
        "Não consegui falar com o modelo local em ${Config.localUrl(ctx)}. Confirme se o servidor está rodando no Termux.", e
    )

    private fun errorText(conn: HttpURLConnection): String =
        conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty().take(200)

    /** Resposta em stream (SSE): cada pedaço chega ao chat conforme é gerado. */
    suspend fun stream(ctx: Context, history: List<ChatMessage>, system: String, json: Boolean, onPartial: suspend (String) -> Unit): String =
        withContext(Dispatchers.IO) {
            val conn = try {
                open(ctx, body(ctx, history, system, true, json))
            } catch (e: IOException) {
                throw unreachable(ctx, e)
            }
            try {
                val code = conn.responseCode
                if (code !in 200..299) throw IllegalStateException("Modelo local respondeu HTTP $code. ${errorText(conn)}")
                val sb = StringBuilder()
                conn.inputStream.bufferedReader().use { reader ->
                    while (true) {
                        val line = reader.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.removePrefix("data:").trim()
                        if (data == "[DONE]") break
                        val piece = try {
                            JSONObject(data).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content").orEmpty()
                        } catch (e: Exception) {
                            ""
                        }
                        if (piece.isNotEmpty()) {
                            sb.append(piece)
                            onPartial(sb.toString())
                        }
                    }
                }
                sb.toString().ifBlank { "O modelo local não retornou texto." }
            } finally {
                conn.disconnect()
            }
        }

    /** Resposta única, usada pelo agente e pela confirmação das ações. */
    suspend fun complete(ctx: Context, history: List<ChatMessage>, system: String, json: Boolean): String =
        withContext(Dispatchers.IO) {
            val conn = try {
                open(ctx, body(ctx, history, system, false, json))
            } catch (e: IOException) {
                throw unreachable(ctx, e)
            }
            try {
                val code = conn.responseCode
                if (code !in 200..299) throw IllegalStateException("Modelo local respondeu HTTP $code. ${errorText(conn)}")
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                JSONObject(text).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
                    .ifBlank { "O modelo local não retornou texto." }
            } finally {
                conn.disconnect()
            }
        }
}
