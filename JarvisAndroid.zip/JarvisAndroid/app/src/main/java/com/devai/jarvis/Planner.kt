package com.devai.jarvis

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

/**
 * Planejador de tarefas: divide um pedido em passos com dependências, executa
 * cada passo de verdade e só afirma como concluído o que teve status "ok".
 *
 * - Passos sem dependência pendente rodam juntos, se não mexem na tela.
 * - Passos que mexem na tela (agent, open_app) rodam um de cada vez.
 * - Cada passo tem timeout e uma nova tentativa em caso de erro.
 * - Passos que dependem de um passo falho são pulados e reportados.
 */
object Planner {
    @Volatile
    var stopRequested = false

    private const val MAX_STEPS = 8
    private const val STEP_TIMEOUT_MS = 240_000L

    private const val PLAN_PROMPT = """Você planeja tarefas para o assistente JARVIS em um celular Android.
Responda APENAS um JSON: {"steps":[{"id":"1","title":"descrição curta","tool":"open_app|agent|answer","input":"texto","depends_on":[]}]}
Ferramentas:
- open_app: input é o nome do app a abrir.
- agent: input é um objetivo de tela em linguagem natural (navegar, tocar, digitar) que o controle do celular executa.
- answer: input é uma tarefa de texto que o modelo responde usando os resultados dos passos anteriores.
Regras: no máximo 8 passos. depends_on lista os ids que precisam terminar antes. Não invente passos que o pedido não exige."""

    data class Step(val id: String, val title: String, val tool: String, val input: String, val deps: List<String>)

    class Result(val step: Step) {
        var status = "pending" // pending, running, ok, failed, skipped
        var output = ""
    }

    suspend fun run(ctx: Context, goal: String, key: String, model: String, report: suspend (String) -> Unit): String {
        stopRequested = false
        val plan = makePlan(ctx, goal, key, model)
        if (plan.isEmpty()) return "Não consegui montar um plano para esse pedido. Tente dividi-lo em partes menores."
        val results = plan.associate { it.id to Result(it) }
        report("▸ Plano com ${plan.size} passo(s): " + plan.joinToString(" → ") { it.title })

        while (results.values.any { it.status == "pending" }) {
            if (stopRequested) {
                results.values.filter { it.status == "pending" }.forEach { it.status = "skipped"; it.output = "interrompido por você" }
                break
            }
            results.values.filter { r ->
                r.status == "pending" && r.step.deps.any { d -> results[d]?.status in listOf("failed", "skipped") }
            }.forEach { it.status = "skipped"; it.output = "depende de um passo que falhou" }

            val ready = results.values.filter { r -> r.status == "pending" && r.step.deps.all { d -> results[d]?.status == "ok" } }
            if (ready.isEmpty()) {
                results.values.filter { it.status == "pending" }.forEach { it.status = "skipped"; it.output = "dependências não resolvidas" }
                break
            }
            ready.forEach { it.status = "running" }
            val (screenSteps, textSteps) = ready.partition { it.step.tool != "answer" }
            coroutineScope {
                textSteps.map { r -> async { execute(ctx, r, results, key, model) } }.forEach { it.await() }
            }
            for (r in screenSteps) execute(ctx, r, results, key, model)

            for (r in ready) {
                val mark = when (r.status) { "ok" -> "concluído"; "skipped" -> "pulado"; else -> "falhou" }
                report("▸ ${r.step.title}: $mark${if (r.status != "ok") " (${r.output.take(160)})" else ""}")
            }
        }

        val okOutputs = results.values.filter { it.status == "ok" && it.step.tool != "answer" }
            .joinToString("\n") { "[${it.step.title}] ${it.output.take(600)}" }
        val statusLines = results.values.joinToString("\n") {
            "- ${it.step.title}: ${it.status}${if (it.status != "ok") " (${it.output.take(200)})" else ""}"
        }
        return Brain.callAny(
            ctx,
            listOf(ChatMessage("Pedido original: $goal\nStatus real dos passos:\n$statusLines\nSaídas dos passos concluídos:\n$okOutputs", true)),
            key, model, null,
            "Escreva a resposta final ao usuário em português, de forma objetiva. Diga apenas o que está com status ok. Liste o que falhou ou foi pulado e o motivo. Nunca diga que algo foi feito se o status não for ok."
        )
    }

    private suspend fun makePlan(ctx: Context, goal: String, key: String, model: String): List<Step> {
        val raw = Brain.callAny(ctx, listOf(ChatMessage("Pedido: $goal", true)), key, model, null, PLAN_PROMPT, json = true)
        val s = raw.replace("```json", "").replace("```", "").trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return emptyList()
        val arr = try {
            JSONObject(s.substring(a, b + 1)).optJSONArray("steps")
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        val tools = setOf("open_app", "agent", "answer")
        val steps = mutableListOf<Step>()
        for (i in 0 until minOf(arr.length(), MAX_STEPS)) {
            val o = arr.optJSONObject(i) ?: continue
            val tool = o.optString("tool")
            if (tool !in tools) continue
            val id = o.optString("id").ifBlank { (i + 1).toString() }
            val depsArr = o.optJSONArray("depends_on")
            val deps = if (depsArr == null) emptyList() else (0 until depsArr.length()).map { depsArr.optString(it) }
            steps.add(Step(id, o.optString("title").ifBlank { tool }, tool, o.optString("input"), deps))
        }
        val ids = steps.map { it.id }.toSet()
        return steps.map { st -> st.copy(deps = st.deps.filter { it in ids && it != st.id }) }
    }

    private suspend fun execute(ctx: Context, r: Result, results: Map<String, Result>, key: String, model: String) {
        val context = results.values.filter { it.status == "ok" }.joinToString("\n") { "[${it.step.title}] ${it.output.take(800)}" }
        var attempt = 0
        while (true) {
            attempt++
            try {
                val out = withTimeout(STEP_TIMEOUT_MS) { runTool(ctx, r.step, context, key, model) }
                r.output = out
                r.status = if (r.step.tool != "answer" && looksFailed(out)) "failed" else "ok"
                return
            } catch (e: TimeoutCancellationException) {
                r.status = "failed"
                r.output = "tempo esgotado"
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (attempt >= 2 || stopRequested) {
                    r.status = "failed"
                    r.output = e.message ?: "erro desconhecido"
                    return
                }
                delay(1500)
            }
        }
    }

    private suspend fun runTool(ctx: Context, step: Step, context: String, key: String, model: String): String = when (step.tool) {
        "open_app" -> Actions(ctx).run("open_app", step.input)
        "agent" -> Agent.run(ctx, step.input, key, model)
        "answer" -> Brain.callAny(
            ctx,
            listOf(ChatMessage("Resultados dos passos anteriores:\n$context\n\nTarefa: ${step.input}", true)),
            key, model, null,
            "Responda em português, de forma objetiva, usando apenas os resultados informados. Se faltar informação, diga."
        )
        else -> throw IllegalStateException("ferramenta desconhecida: ${step.tool}")
    }

    private fun looksFailed(text: String): Boolean {
        val t = text.lowercase()
        return listOf("não consegui", "não encontrei", "não foi possível", "ative o serviço", "parei", "interrompid", "sensível")
            .any { t.contains(it) }
    }
}
