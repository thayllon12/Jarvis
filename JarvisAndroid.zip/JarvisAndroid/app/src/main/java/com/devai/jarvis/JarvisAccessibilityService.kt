package com.devai.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Elemento da tela com índice estável dentro de um snapshot. */
class UiEl(
    val idx: Int,
    val kind: String,
    val label: String,
    val clickable: Boolean,
    val editable: Boolean,
    val bounds: Rect,
    val node: AccessibilityNodeInfo
)

class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null || out.length > 4000) return
        val text = node.text?.toString().orEmpty().ifBlank { node.contentDescription?.toString().orEmpty() }
        if (text.isNotBlank()) out.append(text).append('\n')
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) findScrollable(node.getChild(i))?.let { return it }
        return null
    }

    private fun findEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) findEditable(node.getChild(i))?.let { return it }
        return null
    }

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString().orEmpty()

    fun readScreen(): String {
        val out = StringBuilder()
        collect(rootInActiveWindow, out)
        return out.toString().trim()
    }

    /** Lista os elementos visíveis e interativos, com índices usados pelo agente. */
    fun snapshot(): List<UiEl> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = mutableListOf<UiEl>()
        walk(root, out, 0)
        return out
    }

    private fun walk(node: AccessibilityNodeInfo?, out: MutableList<UiEl>, depth: Int) {
        if (node == null || depth > 40 || out.size >= 150) return
        val label = node.text?.toString().orEmpty().ifBlank { node.contentDescription?.toString().orEmpty() }.trim()
        if ((label.isNotBlank() || node.isClickable || node.isEditable) && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (!r.isEmpty) {
                val kind = when {
                    node.isEditable -> "campo"
                    node.isClickable -> "botão"
                    else -> "texto"
                }
                out.add(UiEl(out.size, kind, label.take(120), node.isClickable, node.isEditable, r, node))
            }
        }
        for (i in 0 until node.childCount) walk(node.getChild(i), out, depth + 1)
    }

    fun tapElement(el: UiEl): Boolean {
        if (el.clickable) {
            var t: AccessibilityNodeInfo? = el.node
            while (t != null && !t.isClickable) t = t.parent
            if (t?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
        }
        val x = el.bounds.exactCenterX()
        val y = el.bounds.exactCenterY()
        return gesture(x, y, x, y, 60)
    }

    fun typeInto(el: UiEl?, text: String): Boolean {
        val target = el?.node
            ?: rootInActiveWindow?.let { it.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(it) }
            ?: return false
        if (el != null) target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            var target: AccessibilityNodeInfo? = n
            while (target != null && !target.isClickable) target = target.parent
            if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun typeText(text: String): Boolean = typeInto(null, text)

    fun scroll(forward: Boolean): Boolean {
        val node = findScrollable(rootInActiveWindow) ?: return false
        return node.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun swipeDir(dir: String): Boolean {
        val m = resources.displayMetrics
        val cx = m.widthPixels / 2f
        val cy = m.heightPixels / 2f
        val v = m.heightPixels / 3f
        val h = m.widthPixels / 3f
        return when (dir) {
            "up" -> gesture(cx, cy + v, cx, cy - v, 350)
            "down" -> gesture(cx, cy - v, cx, cy + v, 350)
            "left" -> gesture(cx + h, cy, cx - h, cy, 350)
            "right" -> gesture(cx - h, cy, cx + h, cy, 350)
            else -> false
        }
    }

    fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null

        fun perform(action: Int): Boolean = instance?.performGlobalAction(action) ?: false
    }
}
