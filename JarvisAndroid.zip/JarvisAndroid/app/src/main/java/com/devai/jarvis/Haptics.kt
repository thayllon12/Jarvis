package com.devai.jarvis

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator

object Haptics {
    /** Toque mínimo a cada caractere revelado da resposta. */
    fun tick(ctx: Context) {
        if (!Config.hapticTyping(ctx)) return
        val v = ctx.getSystemService(Vibrator::class.java) ?: return
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(6, 35))
    }

    /** Toque curto quando a resposta começa a chegar. */
    fun replyStart(ctx: Context) {
        if (!Config.hapticOn(ctx)) return
        val v = ctx.getSystemService(Vibrator::class.java) ?: return
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(18, 60))
    }
}
