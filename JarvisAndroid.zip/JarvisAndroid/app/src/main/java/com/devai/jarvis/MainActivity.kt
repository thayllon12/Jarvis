package com.devai.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Night = Color(0xFF050A13)
private val Panel = Color(0xFF0A1726)
private val Cyan = Color(0xFF39D9FF)
private val Muted = Color(0xFF7FA8BC)

class MainActivity : ComponentActivity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR") }
        setContent { JarvisScreen(onListen = { startListening() }, onSpeak = { speak(it) }, onOpenApp = { openApp(it) }) }
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Reconhecimento de voz indisponível neste aparelho", Toast.LENGTH_LONG).show(); return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o JARVIS")
        }
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { Toast.makeText(this@MainActivity, "Não consegui entender. Tente novamente.", Toast.LENGTH_SHORT).show() }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!phrase.isNullOrBlank()) (this@MainActivity as? MainActivity)?.window?.decorView?.post { VoiceBus.submit(phrase) }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer?.startListening(intent)
    }

    private fun openApp(query: String): String {
        val normalized = query.lowercase(Locale.ROOT).trim()
        val aliases = mapOf("youtube" to listOf("youtube"), "whatsapp" to listOf("whatsapp"), "instagram" to listOf("instagram"), "spotify" to listOf("spotify"), "lark player" to listOf("lark"), "chrome" to listOf("chrome"), "configurações" to listOf("settings"))
        val terms = aliases[normalized] ?: listOf(normalized)
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val found = apps.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString().lowercase(Locale.ROOT)
            terms.any { label.contains(it) || app.packageName.lowercase(Locale.ROOT).contains(it) }
        }
        if (found != null) {
            val launch = pm.getLaunchIntentForPackage(found.packageName)
            if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); return "Abrindo ${pm.getApplicationLabel(found)}." }
        }
        if (normalized.contains("config")) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); return "Abrindo as configurações do Android." }
        return "Não encontrei o aplicativo $query instalado."
    }

    override fun onDestroy() {
        speechRecognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}

private object VoiceBus {
    var callback: ((String) -> Unit)? = null
    fun submit(value: String) { callback?.invoke(value) }
}

private data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
private fun JarvisScreen(onListen: () -> Unit, onSpeak: (String) -> Unit, onOpenApp: (String) -> String) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_settings", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-2.0-flash") ?: "gemini-2.0-flash") }
    var voiceEnabled by remember { mutableStateOf(prefs.getBoolean("voice", true)) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("ONLINE") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatMessage("Olá. Eu sou o JARVIS. Como posso ajudar?", false)) }
    val scope = rememberCoroutineScope()
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onListen() else Toast.makeText(context, "Permissão de microfone necessária", Toast.LENGTH_SHORT).show()
    }
    DisposableEffect(Unit) { VoiceBus.callback = { input = it; scope.launch { sendMessage(it, apiKey, model, messages, onSpeak, onOpenApp, voiceEnabled) { s, b -> status = s; busy = b } } }; onDispose { VoiceBus.callback = null } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071626), Night, Color(0xFF02050B))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("J A R V I S", color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                    Text("PERSONAL AI ASSISTANT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("20°  •  BRASIL", color = Color.White.copy(.8f), fontSize = 10.sp)
                    Text("● $status", color = if (busy) Color(0xFFFFC45B) else Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                }
                Spacer(Modifier.width(10.dp))
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Configurações", tint = Cyan) }
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                HudCore(active = busy)
                Column(Modifier.align(Alignment.TopCenter).padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SEU ASSISTENTE PESSOAL", color = Color.White.copy(.9f), fontSize = 12.sp, letterSpacing = 1.5.sp)
                    Text("Sempre pronto para ajudar", color = Muted, fontSize = 10.sp)
                }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (busy) "PROCESSANDO SOLICITAÇÃO" else "F I S H   •   S I S T E M A   A T I V O", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                    Text("GEMINI  •  ${model.uppercase()}", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
                }
            }
            Text("CONVERSA", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp, modifier = Modifier.padding(bottom = 6.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(min = 56.dp, max = 148.dp), reverseLayout = true, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(messages.asReversed()) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(msg.text, color = Color(0xFFE4F7FF), fontSize = 12.sp, modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(13.dp)).background(if (msg.fromUser) Color(0xFF12364B) else Panel).border(1.dp, Cyan.copy(.18f), RoundedCornerShape(13.dp)).padding(horizontal = 12.dp, vertical = 9.dp))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0xFF0A1C2A)).border(1.dp, Cyan.copy(.35f), RoundedCornerShape(28.dp)).padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { showSettings = true }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Settings, "Opções", tint = Muted, modifier = Modifier.size(17.dp)) }
                BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(horizontal = 7.dp), textStyle = TextStyle(color = Color.White, fontSize = 13.sp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), decorationBox = { inner -> if (input.isEmpty()) Text("Fale com o JARVIS...", color = Muted, fontSize = 12.sp); inner() })
                IconButton(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) onListen() else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Mic, "Falar", tint = Cyan, modifier = Modifier.size(19.dp)) }
                IconButton(onClick = { val text = input.trim(); if (text.isNotEmpty() && !busy) { input = ""; scope.launch { sendMessage(text, apiKey, model, messages, onSpeak, onOpenApp, voiceEnabled) { s, b -> status = s; busy = b } } } }, modifier = Modifier.size(38.dp).clip(CircleShape).background(Cyan)) { Icon(Icons.Default.Send, "Enviar", tint = Night, modifier = Modifier.size(17.dp)) }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    if (showSettings) {
        AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Color(0xFF0B1A29), title = { Text("Configurações do JARVIS", color = Color.White) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("CHAVE API DO GEMINI", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Cole sua API Key") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedLabelColor = Cyan, unfocusedLabelColor = Muted))
                Text("MODELO", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                OutlinedTextField(value = model, onValueChange = { model = it }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted))
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Responder usando voz", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = voiceEnabled, onCheckedChange = { voiceEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f))) }
                Text("A chave fica salva somente neste aparelho. Obtenha uma chave em aistudio.google.com.", color = Muted, fontSize = 10.sp)
            }
        }, confirmButton = { TextButton(onClick = { prefs.edit().putString("api_key", apiKey.trim()).putString("model", model.trim().ifBlank { "gemini-2.0-flash" }).putBoolean("voice", voiceEnabled).apply(); showSettings = false }) { Text("SALVAR", color = Cyan) } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("CANCELAR", color = Muted) } })
    }
}

@Composable
private fun HudCore(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "hud")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 3500 else 9000, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "rotation")
    val pulse by transition.animateFloat(.92f, 1.06f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    Canvas(Modifier.size(286.dp).alpha(pulse)) {
        val c = center; val base = size.minDimension / 2f
        drawCircle(Cyan.copy(.035f), radius = base * .95f)
        for (i in 0..5) drawCircle(Cyan.copy(if (i % 2 == 0) .30f else .12f), radius = base * (.42f + i * .085f), style = Stroke(width = if (i == 5) 1.6f else 1f, pathEffect = null))
        drawCircle(Color(0xFF1DAFDC).copy(.10f), radius = base * .34f)
        for (i in 0 until 72) {
            val a = Math.toRadians((i * 5.0 + rotation).toDouble()).toFloat()
            val r1 = base * if (i % 6 == 0) .70f else .76f
            val r2 = base * if (i % 6 == 0) .84f else .80f
            val x1 = c.x + kotlin.math.cos(a) * r1; val y1 = c.y + kotlin.math.sin(a) * r1
            val x2 = c.x + kotlin.math.cos(a) * r2; val y2 = c.y + kotlin.math.sin(a) * r2
            drawLine(Cyan.copy(if (i % 6 == 0) .9f else .42f), androidx.compose.ui.geometry.Offset(x1, y1), androidx.compose.ui.geometry.Offset(x2, y2), strokeWidth = if (i % 6 == 0) 2.4f else 1f, cap = StrokeCap.Round)
        }
        for (i in 0 until 3) {
            val start = rotation + i * 120f
            drawArc(Cyan.copy(.7f), start, 45f, false, topLeft = androidx.compose.ui.geometry.Offset(c.x - base * (.88f - i * .07f), c.y - base * (.88f - i * .07f)), size = androidx.compose.ui.geometry.Size(base * (1.76f - i * .14f), base * (1.76f - i * .14f)), style = Stroke(width = 2.2f, cap = StrokeCap.Round))
        }
        drawCircle(Cyan.copy(.20f), radius = base * .26f)
        drawCircle(Cyan.copy(.9f), radius = base * .19f, style = Stroke(width = 2f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFB9F8FF), Color(0xFF21BDEB), Color(0xFF075078))), radius = base * .135f)
        drawCircle(Color.White.copy(.7f), radius = base * .035f)
    }
}

private suspend fun sendMessage(
    text: String,
    key: String,
    model: String,
    messages: MutableList<ChatMessage>,
    speak: (String) -> Unit,
    openApp: (String) -> String,
    voiceEnabled: Boolean,
    update: (String, Boolean) -> Unit
) {
    messages.add(ChatMessage(text, true))
    update("PENSANDO", true)
    val lower = text.lowercase(Locale.ROOT)
    val localResponse = when {
        lower.startsWith("abrir ") || lower.startsWith("abra ") || lower.startsWith("abre ") -> openApp(text.substringAfter(' ').trim())
        lower.contains("que horas") || lower.contains("horário") -> "Agora são ${java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(java.util.Date())}."
        lower.startsWith("tocar ") || lower.startsWith("reproduzir ") || lower.startsWith("toque ") -> {
            val song = text.substringAfter(' ').trim()
            "Para tocar $song, abra seu aplicativo de música e selecione a faixa. O Android não permite que um app controle todos os players de terceiros sem integração específica."
        }
        else -> null
    }
    val response = if (localResponse != null) localResponse else if (key.isBlank()) {
        "Configure sua chave API do Gemini nas configurações para ativar minhas respostas inteligentes. Os comandos locais para abrir aplicativos e consultar as horas continuam disponíveis."
    } else {
        try { callGemini(text, key, model) } catch (e: Exception) { "Não consegui acessar o Gemini: ${e.message ?: "erro de conexão"}. Verifique sua API Key e sua internet." }
    }
    messages.add(ChatMessage(response, false))
    if (voiceEnabled) speak(response)
    update("ONLINE", false)
}

private suspend fun callGemini(prompt: String, key: String, model: String): String = withContext(Dispatchers.IO) {
    val safeModel = model.trim().ifBlank { "gemini-2.0-flash" }
    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent?key=${Uri.encode(key)}")
    val body = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Você é JARVIS, um assistente pessoal Android. Responda em português brasileiro, de forma natural, direta e útil. Não afirme que executou ações no celular quando elas não foram realmente executadas. Explique limitações quando necessário."))))
        .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
    val connection = (url.openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true; setRequestProperty("Content-Type", "application/json") }
    try {
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val result = stream.bufferedReader().use { it.readText() }
        val json = JSONObject(result)
        if (code !in 200..299) throw IllegalStateException(json.optJSONObject("error")?.optString("message") ?: "HTTP $code")
        json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            ?.takeIf { it.isNotBlank() } ?: "Não recebi uma resposta válida do Gemini."
    } finally { connection.disconnect() }
}
