package com.devai.jarvis

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.StopScreenShare
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF050A13)
private val Panel = Color(0xFF0A1726)
private val Cyan = Color(0xFF39D9FF)
private val Muted = Color(0xFF7FA8BC)
private val Ok = Color(0xFF4CE08A)
private val Warn = Color(0xFFFFC45B)

class MainActivity : ComponentActivity() {
    private var input: VoiceInput? = null
    private val resumeTick = mutableIntStateOf(0)
    private val listenFailTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brain.init(this)
        if (Config.wakeOn(this) && android.provider.Settings.canDrawOverlays(this) && Perms.has(this, Manifest.permission.RECORD_AUDIO) && !BubbleService.running) {
            BubbleService.start(this)
        }
        input = VoiceInput(this, onText = { text -> VoiceBus.submit(text) }, onEnd = { ok ->
            if (!ok) listenFailTick.intValue = listenFailTick.intValue + 1
        })
        setContent { JarvisScreen(resumeTick.intValue, listenFailTick.intValue, onListen = { input?.start() }) }
    }

    override fun onResume() {
        super.onResume()
        AppState.visible = true
        resumeTick.intValue = resumeTick.intValue + 1
    }

    override fun onPause() {
        AppState.visible = false
        super.onPause()
    }

    override fun onDestroy() {
        input?.destroy()
        super.onDestroy()
    }
}

private object VoiceBus {
    var callback: ((String) -> Unit)? = null
    fun submit(value: String) { callback?.invoke(value) }
}

@Composable
private fun JarvisScreen(tick: Int, failTick: Int, onListen: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { Config.prefs(context) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(Config.model(context)) }
    var voiceEnabled by remember { mutableStateOf(Config.voiceEnabled(context)) }
    var elevenOn by remember { mutableStateOf(Config.elevenEnabled(context)) }
    var elevenKey by remember { mutableStateOf(prefs.getString("eleven_key", "") ?: "") }
    var voiceId by remember { mutableStateOf(Config.voiceId(context)) }
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showPerms by remember { mutableStateOf(false) }
    var pendingListen by remember { mutableStateOf(false) }
    var continuous by remember { mutableStateOf(false) }
    var wakeOn by remember { mutableStateOf(Config.wakeOn(context)) }
    val attachments = remember { mutableStateListOf<FileIO.Picked>() }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val haptics = LocalHapticFeedback.current
    val messages = Brain.messages
    val busy = Brain.busy
    val sessions = Brain.sessions

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (pendingListen) {
            pendingListen = false
            if (result[Manifest.permission.RECORD_AUDIO] == true || Perms.has(context, Manifest.permission.RECORD_AUDIO)) onListen()
            else Toast.makeText(context, "Permissão de microfone necessária", Toast.LENGTH_SHORT).show()
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val picked = withContext(Dispatchers.IO) { FileIO.pickAll(context, uris) }
            attachments.addAll(picked)
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) scope.launch {
            attachments.add(withContext(Dispatchers.IO) { FileIO.fromBitmap(bmp) })
        }
    }

    fun send(text: String) {
        val clean = text.trim()
        if ((clean.isBlank() && attachments.isEmpty()) || Brain.busy) return
        val picked = attachments.toList()
        attachments.clear()
        FileIO.send(context, clean.ifBlank { "Analise o(s) anexo(s)." }, picked)
    }

    fun micPressed() {
        if (Perms.has(context, Manifest.permission.RECORD_AUDIO)) onListen()
        else { pendingListen = true; permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
    }

    LaunchedEffect(Unit) {
        if (!prefs.getBoolean("perms_asked", false)) {
            prefs.edit().putBoolean("perms_asked", true).apply()
            val missing = Perms.missing(context)
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
            showPerms = true
        }
    }

    DisposableEffect(Unit) {
        VoiceBus.callback = { phrase -> send(phrase) }
        onDispose { VoiceBus.callback = null }
    }

    // Voz contínua: volta a ouvir quando a resposta termina ou quando a escuta falha.
    LaunchedEffect(continuous, busy, failTick) {
        if (continuous && !busy) {
            delay(500)
            if (continuous && !Brain.busy && Perms.has(context, Manifest.permission.RECORD_AUDIO)) onListen()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF07101C), drawerContentColor = Color.White) {
                Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 14.dp, vertical = 16.dp)) {
                    Text("J A R V I S", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(onClick = {
                        Brain.newChat(context)
                        scope.launch { drawerState.close() }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, null, tint = Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text("Nova conversa", color = Cyan)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("HISTÓRICO", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(sessions.toList()) { s ->
                            val selected = s.id == Brain.currentId
                            Text(
                                s.title,
                                color = if (selected) Cyan else Color.White,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) Cyan.copy(.12f) else Color.Transparent)
                                    .clickable {
                                        Brain.openChat(context, s.id)
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                    }
                    TextButton(onClick = {
                        scope.launch { drawerState.close() }
                        Toast.makeText(context, if (BubbleService.running) BubbleService.stop(context) else BubbleService.start(context), Toast.LENGTH_SHORT).show()
                    }) { Text(if (BubbleService.running) "Desligar bolinha" else "Ligar bolinha", color = Cyan) }
                    TextButton(onClick = {
                        wakeOn = !wakeOn
                        prefs.edit().putBoolean("wake_on", wakeOn).apply()
                        BubbleService.refreshWake(context)
                        if (wakeOn && !BubbleService.running && android.provider.Settings.canDrawOverlays(context)) BubbleService.start(context)
                        scope.launch { drawerState.close() }
                    }) { Text(if (wakeOn) "Ouvir \"Jarvis\": ligado" else "Ouvir \"Jarvis\": desligado", color = Cyan) }
                    TextButton(onClick = { scope.launch { drawerState.close() }; showPerms = true }) { Text("Permissões", color = Muted) }
                    TextButton(onClick = { scope.launch { drawerState.close() }; showSettings = true }) { Text("Configurações", color = Muted) }
                }
            }
        }
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071626), Night, Color(0xFF02050B))))) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 14.dp)) {
                // Barra superior
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "Menu", tint = Cyan) }
                    Column(Modifier.weight(1f)) {
                        Text("J A R V I S", color = Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                        Text(
                            if (busy) "PROCESSANDO" else "ONLINE  •  ${model.uppercase()}",
                            color = if (busy) Warn else Muted,
                            fontSize = 9.sp,
                            letterSpacing = 1.sp
                        )
                    }
                    IconButton(onClick = { continuous = !continuous }) {
                        Icon(Icons.Default.Hearing, "Voz contínua", tint = if (continuous) Ok else Muted)
                    }
                    IconButton(onClick = { Toast.makeText(context, ScreenShare.request(context, !ScreenShare.active), Toast.LENGTH_SHORT).show() }) {
                        Icon(if (ScreenShare.active) Icons.Default.StopScreenShare else Icons.Default.ScreenShare, "Compartilhar tela", tint = if (ScreenShare.active) Ok else Muted)
                    }
                    IconButton(onClick = { showPerms = true }) {
                        Icon(Icons.Default.Security, "Permissões", tint = if (Perms.missing(context).isEmpty() && Perms.special(context).all { it.granted }) Ok else Warn)
                    }
                }

                // Conversa
                if (messages.size <= 1) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        HudCore(active = busy)
                        Text(
                            if (ScreenShare.active) "Vendo sua tela" else "Sempre pronto para ajudar",
                            color = if (ScreenShare.active) Ok else Muted,
                            fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp),
                        reverseLayout = true,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages.asReversed()) { msg -> ChatBubble(msg) }
                    }
                }

                // Campo de entrada
                Column(
                    Modifier.fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF0A1C2A))
                        .border(1.dp, Cyan.copy(.3f), RoundedCornerShape(24.dp))
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    if (attachments.isNotEmpty()) {
                        LazyRow(
                            Modifier.padding(start = 6.dp, bottom = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(attachments.toList()) { p -> AttachChip(p.name) { attachments.remove(p) } }
                        }
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        IconButton(onClick = { filePicker.launch("*/*") }, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Default.AttachFile, "Anexar arquivo", tint = Cyan, modifier = Modifier.size(19.dp))
                        }
                        IconButton(onClick = { cameraLauncher.launch(null) }, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Default.CameraAlt, "Tirar foto", tint = Cyan, modifier = Modifier.size(19.dp))
                        }
                        BasicTextField(
                            value = input,
                            onValueChange = {
                                // Vibração leve ao digitar
                                if (it.length > input.length) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                input = it
                            },
                            modifier = Modifier.weight(1f).padding(horizontal = 6.dp, vertical = 10.dp),
                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp, lineHeight = 19.sp),
                            maxLines = 6,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            decorationBox = { inner ->
                                if (input.isEmpty()) Text("Fale com o JARVIS...", color = Muted, fontSize = 13.sp)
                                inner()
                            }
                        )
                        IconButton(onClick = { micPressed() }, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Default.Mic, "Falar", tint = Cyan, modifier = Modifier.size(19.dp))
                        }
                        // Enviar vira Parar enquanto a resposta é gerada
                        IconButton(
                            onClick = {
                                if (busy) Brain.requestStop()
                                else if (input.isNotBlank() || attachments.isNotEmpty()) {
                                    val t = input
                                    input = ""
                                    send(t)
                                }
                            },
                            modifier = Modifier.size(38.dp).clip(CircleShape).background(if (busy) Warn else Cyan)
                        ) {
                            Icon(
                                if (busy) Icons.Default.Stop else Icons.Default.Send,
                                if (busy) "Parar" else "Enviar",
                                tint = Night,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showPerms) {
        val missing = remember(tick, showPerms) { Perms.missing(context) }
        val special = remember(tick, showPerms) { Perms.special(context) }
        AlertDialog(
            onDismissRequest = { showPerms = false },
            containerColor = Color(0xFF0B1A29),
            title = { Text("Permissões do JARVIS", color = Color.White) },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 420.dp)) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("PERMISSÕES PADRÃO", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                            val total = Perms.runtime().size
                            Text("${total - missing.size} de $total concedidas", color = if (missing.isEmpty()) Ok else Warn, fontSize = 12.sp)
                            if (missing.isNotEmpty()) {
                                Button(onClick = { permissionLauncher.launch(missing.toTypedArray()) }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)) { Text("CONCEDER TODAS") }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("ACESSOS ESPECIAIS", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                        }
                    }
                    items(special) { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(item.description, color = Muted, fontSize = 10.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                            if (item.granted) Text("ATIVO", color = Ok, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            else TextButton(onClick = { Perms.open(context, item.intent) }) { Text("ATIVAR", color = Warn) }
                        }
                    }
                    item {
                        Text("No Android 13+, apps instalados fora da loja podem exigir: Info do app > menu ⋮ > Permitir configurações restritas, antes de ativar Acessibilidade e Notificações.", color = Muted, fontSize = 10.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPerms = false }) { Text("FECHAR", color = Cyan) } },
            dismissButton = { TextButton(onClick = { Perms.open(context, Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }) { Text("INFO DO APP", color = Muted) } }
        )
    }

    if (showSettings) {
        val fieldColors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedLabelColor = Cyan, unfocusedLabelColor = Muted)
        AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Color(0xFF0B1A29), title = { Text("Configurações do JARVIS", color = Color.White) }, text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 440.dp)) {
                item { Text("CHAVE API DO GEMINI", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
                item { OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Cole sua API Key") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { Text("MODELO", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
                item { OutlinedTextField(value = model, onValueChange = { model = it }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { Text("ELEVENLABS", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Usar voz da ElevenLabs", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = elevenOn, onCheckedChange = { elevenOn = it }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f))) } }
                item { OutlinedTextField(value = elevenKey, onValueChange = { elevenKey = it }, label = { Text("API Key (vazio usa a do build)") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { OutlinedTextField(value = voiceId, onValueChange = { voiceId = it }, label = { Text("ID da voz") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Responder usando voz", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = voiceEnabled, onCheckedChange = { voiceEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f))) } }
                item { Text("As chaves ficam salvas somente neste aparelho.", color = Muted, fontSize = 10.sp) }
            }
        }, confirmButton = {
            TextButton(onClick = {
                prefs.edit()
                    .putString("api_key", apiKey.trim())
                    .putString("model", model.trim().ifBlank { Config.DEFAULT_MODEL })
                    .putBoolean("voice", voiceEnabled)
                    .putBoolean("eleven_on", elevenOn)
                    .putString("eleven_key", elevenKey.trim())
                    .putString("voice_id", voiceId.trim().ifBlank { Config.DEFAULT_VOICE_ID })
                    .apply()
                showSettings = false
            }) { Text("SALVAR", color = Cyan) }
        }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("CANCELAR", color = Muted) } })
    }
}

@Composable
private fun ChatBubble(msg: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
        val bg = when {
            msg.fromUser -> Color(0xFF12364B)
            msg.system -> Color(0xFF071C2B)
            else -> Panel
        }
        Column(
            Modifier.widthIn(max = 320.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(bg)
                .border(1.dp, Cyan.copy(.18f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 9.dp)
        ) {
            MessageContent(msg.text, msg.system)
        }
    }
}

private data class Seg(val code: Boolean, val text: String, val lang: String)

/** Separa o texto em trechos normais e blocos de código (```lang ... ```). */
private fun segments(text: String): List<Seg> = text.split("```").mapIndexedNotNull { i, p ->
    if (i % 2 == 0) {
        if (p.isBlank()) null else Seg(false, p.trim(), "")
    } else {
        val first = p.substringBefore('\n')
        val hasLang = p.contains('\n') && first.trim().let { it.isEmpty() || (it.length <= 15 && !it.contains(' ')) }
        if (hasLang) Seg(true, p.substringAfter('\n').trimEnd(), first.trim())
        else Seg(true, p.trim(), "")
    }
}

@Composable
private fun MessageContent(text: String, system: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        segments(text).forEach { seg ->
            if (seg.code) CodeBlock(seg.text, seg.lang)
            else Text(seg.text, color = if (system) Cyan else Color(0xFFE4F7FF), fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun CodeBlock(code: String, lang: String) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF020811))
            .border(1.dp, Cyan.copy(.2f), RoundedCornerShape(10.dp))
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 4.dp, top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(lang.ifBlank { "código" }, color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("código", code))
                Toast.makeText(ctx, "Código copiado", Toast.LENGTH_SHORT).show()
            }, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.ContentCopy, "Copiar código", tint = Cyan, modifier = Modifier.size(15.dp))
            }
        }
        Text(
            code,
            color = Color(0xFFBDEFFF),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(10.dp)
        )
    }
}

@Composable
private fun AttachChip(name: String, onRemove: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp))
            .background(Cyan.copy(.12f))
            .padding(start = 10.dp, end = 2.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name.take(24), color = Cyan, fontSize = 11.sp)
        IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Default.Close, "Remover anexo", tint = Muted, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun HudCore(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "hud")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 3500 else 9000, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "rotation")
    val pulse by transition.animateFloat(.92f, 1.06f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    Canvas(Modifier.size(260.dp).alpha(pulse)) {
        val c = center
        val base = size.minDimension / 2f
        drawCircle(Cyan.copy(.035f), radius = base * .95f)
        for (i in 0..5) drawCircle(Cyan.copy(if (i % 2 == 0) .30f else .12f), radius = base * (.42f + i * .085f), style = Stroke(width = if (i == 5) 1.6f else 1f, pathEffect = null))
        drawCircle(Color(0xFF1DAFDC).copy(.10f), radius = base * .34f)
        for (i in 0 until 72) {
            val a = Math.toRadians((i * 5.0 + rotation).toDouble()).toFloat()
            val r1 = base * if (i % 6 == 0) .70f else .76f
            val r2 = base * if (i % 6 == 0) .84f else .80f
            val x1 = c.x + kotlin.math.cos(a) * r1
            val y1 = c.y + kotlin.math.sin(a) * r1
            val x2 = c.x + kotlin.math.cos(a) * r2
            val y2 = c.y + kotlin.math.sin(a) * r2
            drawLine(Cyan.copy(if (i % 6 == 0) .9f else .42f), androidx.compose.ui.geometry.Offset(x1, y1), androidx.compose.ui.geometry.Offset(x2, y2), strokeWidth = if (i % 6 == 0) 2.4f else 1f, cap = StrokeCap.Round)
        }
        for (i in 0 until 3) {
            val start = rotation + i * 120f
            drawArc(Cyan.copy(.7f), start, 45f, false, topLeft = androidx.compose.ui.geometry.Offset(c.x - base * (.88f - i * .07f), c.y - base * (.88f - i * .07f)), size = androidx.compose.ui.geometry.Size(base * (1.76f - i * .14f), base * (1.76f - i * .14f)), style = Stroke(width = 2.2f, cap = StrokeCap.Round))
        }
        drawCircle(Cyan.copy(.20f), radius = base * .26f)
        drawCircle(Cyan.copy(.9f), radius = base * .19f, style = Stroke(width = 2f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFB9F8FF), Color(0xFF21BDEB), Color(0xFF075078))), radius = base * .135f)
        drawCircle(Color.White.copy(.7f), radius = base * .035f)
    }
}
