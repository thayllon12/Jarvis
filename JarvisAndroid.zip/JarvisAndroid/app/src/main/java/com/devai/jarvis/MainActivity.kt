package com.devai.jarvis

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopScreenShare
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF050A13)
private val Panel = Color(0xFF0A1726)
private val Cyan = Color(0xFF39D9FF)
private val Muted = Color(0xFF7FA8BC)
private val Ok = Color(0xFF4CE08A)
private val Warn = Color(0xFFFFC45B)

class MainActivity : ComponentActivity() {
    private var input: VoiceInput? = null
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        input = VoiceInput(this, onText = { text -> VoiceBus.submit(text) }, onEnd = { ok ->
            if (!ok) Toast.makeText(this, "Não consegui entender. Tente novamente.", Toast.LENGTH_SHORT).show()
        })
        setContent { JarvisScreen(resumeTick.intValue, onListen = { input?.start() }) }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }

    override fun onDestroy() {
        input?.destroy()
        super.onDestroy()
    }
}

private object VoiceBus {
    var callback: ((String) -> Unit)? = null
    fun submit(value: String) { callback?.invoke(value) }
}

@Composable
private fun JarvisScreen(tick: Int, onListen: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { Config.prefs(context) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(Config.model(context)) }
    var voiceEnabled by remember { mutableStateOf(Config.voiceEnabled(context)) }
    var elevenOn by remember { mutableStateOf(Config.elevenEnabled(context)) }
    var elevenKey by remember { mutableStateOf(prefs.getString("eleven_key", "") ?: "") }
    var voiceId by remember { mutableStateOf(Config.voiceId(context)) }
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showPerms by remember { mutableStateOf(false) }
    var pendingListen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val messages = Brain.messages
    val busy = Brain.busy

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (pendingListen) {
            pendingListen = false
            if (result[Manifest.permission.RECORD_AUDIO] == true || Perms.has(context, Manifest.permission.RECORD_AUDIO)) onListen()
            else Toast.makeText(context, "Permissão de microfone necessária", Toast.LENGTH_SHORT).show()
        }
    }

    fun send(text: String) {
        if (text.isNotBlank() && !Brain.busy) scope.launch { Brain.process(context, text) }
    }

    LaunchedEffect(Unit) {
        if (!prefs.getBoolean("perms_asked", false)) {
            prefs.edit().putBoolean("perms_asked", true).apply()
            val missing = Perms.missing(context)
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
            showPerms = true
        }
    }

    DisposableEffect(Unit) {
        VoiceBus.callback = { phrase -> send(phrase) }
        onDispose { VoiceBus.callback = null }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071626), Night, Color(0xFF02050B))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("J A R V I S", color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                    Text("PERSONAL AI ASSISTANT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(SimpleDateFormat("HH:mm  •  dd/MM", Locale("pt", "BR")).format(Date()), color = Color.White.copy(.8f), fontSize = 10.sp)
                    Text("● ${Brain.status}", color = if (busy) Warn else Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (BubbleService.running) Toast.makeText(context, BubbleService.stop(context), Toast.LENGTH_SHORT).show()
                    else {
                        val r = BubbleService.start(context)
                        Toast.makeText(context, r, Toast.LENGTH_LONG).show()
                        if (!android.provider.Settings.canDrawOverlays(context)) showPerms = true
                    }
                }) { Icon(Icons.Default.Layers, "Bolinha", tint = if (BubbleService.running) Ok else Muted) }
                IconButton(onClick = { Toast.makeText(context, ScreenShare.request(context, !ScreenShare.active), Toast.LENGTH_SHORT).show() }) {
                    Icon(if (ScreenShare.active) Icons.Default.StopScreenShare else Icons.Default.ScreenShare, "Compartilhar tela", tint = if (ScreenShare.active) Ok else Muted)
                }
                IconButton(onClick = { showPerms = true }) { Icon(Icons.Default.Security, "Permissões", tint = if (Perms.missing(context).isEmpty() && Perms.special(context).all { it.granted }) Ok else Warn) }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Configurações", tint = Cyan) }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                HudCore(active = busy)
                Column(Modifier.align(Alignment.TopCenter).padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SEU ASSISTENTE PESSOAL", color = Color.White.copy(.9f), fontSize = 12.sp, letterSpacing = 1.5.sp)
                    Text(if (ScreenShare.active) "Vendo sua tela" else "Sempre pronto para ajudar", color = if (ScreenShare.active) Ok else Muted, fontSize = 10.sp)
                }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (busy) "PROCESSANDO SOLICITAÇÃO" else "S I S T E M A   A T I V O", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                    Text("GEMINI  •  ${model.uppercase()}", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
                }
            }
            Text("CONVERSA", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp, modifier = Modifier.padding(bottom = 6.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(min = 56.dp, max = 170.dp), reverseLayout = true, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(messages.asReversed()) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(
                            msg.text,
                            color = if (msg.system) Cyan else Color(0xFFE4F7FF),
                            fontSize = 12.sp,
                            modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(13.dp)).background(if (msg.fromUser) Color(0xFF12364B) else Panel).border(1.dp, Cyan.copy(.18f), RoundedCornerShape(13.dp)).padding(horizontal = 12.dp, vertical = 9.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0xFF0A1C2A)).border(1.dp, Cyan.copy(.35f), RoundedCornerShape(28.dp)).padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(horizontal = 14.dp), textStyle = TextStyle(color = Color.White, fontSize = 13.sp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), decorationBox = { inner -> if (input.isEmpty()) Text("Fale com o JARVIS...", color = Muted, fontSize = 12.sp); inner() })
                IconButton(onClick = {
                    if (Perms.has(context, Manifest.permission.RECORD_AUDIO)) onListen()
                    else { pendingListen = true; permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
                }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Mic, "Falar", tint = Cyan, modifier = Modifier.size(19.dp)) }
                IconButton(onClick = {
                    val text = input.trim()
                    if (text.isNotEmpty()) { input = ""; send(text) }
                }, modifier = Modifier.size(38.dp).clip(CircleShape).background(Cyan)) { Icon(Icons.Default.Send, "Enviar", tint = Night, modifier = Modifier.size(17.dp)) }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    if (showPerms) {
        val missing = remember(tick, showPerms) { Perms.missing(context) }
        val special = remember(tick, showPerms) { Perms.special(context) }
        AlertDialog(
            onDismissRequest = { showPerms = false },
            containerColor = Color(0xFF0B1A29),
            title = { Text("Permissões do JARVIS", color = Color.White) },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 420.dp)) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("PERMISSÕES PADRÃO", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                            val total = Perms.runtime().size
                            Text("${total - missing.size} de $total concedidas", color = if (missing.isEmpty()) Ok else Warn, fontSize = 12.sp)
                            if (missing.isNotEmpty()) {
                                Button(onClick = { permissionLauncher.launch(missing.toTypedArray()) }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)) { Text("CONCEDER TODAS") }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("ACESSOS ESPECIAIS", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                        }
                    }
                    items(special) { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(item.description, color = Muted, fontSize = 10.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                            if (item.granted) Text("ATIVO", color = Ok, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            else TextButton(onClick = { Perms.open(context, item.intent) }) { Text("ATIVAR", color = Warn) }
                        }
                    }
                    item {
                        Text("No Android 13+, apps instalados fora da loja podem exigir: Info do app > menu ⋮ > Permitir configurações restritas, antes de ativar Acessibilidade e Notificações.", color = Muted, fontSize = 10.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPerms = false }) { Text("FECHAR", color = Cyan) } },
            dismissButton = { TextButton(onClick = { Perms.open(context, Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }) { Text("INFO DO APP", color = Muted) } }
        )
    }

    if (showSettings) {
        val fieldColors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedLabelColor = Cyan, unfocusedLabelColor = Muted)
        AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Color(0xFF0B1A29), title = { Text("Configurações do JARVIS", color = Color.White) }, text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 440.dp)) {
                item { Text("CHAVE API DO GEMINI", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
                item { OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Cole sua API Key") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { Text("MODELO", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
                item { OutlinedTextField(value = model, onValueChange = { model = it }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { Text("ELEVENLABS", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp) }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Usar voz da ElevenLabs", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = elevenOn, onCheckedChange = { elevenOn = it }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f))) } }
                item { OutlinedTextField(value = elevenKey, onValueChange = { elevenKey = it }, label = { Text("API Key (vazio usa a do build)") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { OutlinedTextField(value = voiceId, onValueChange = { voiceId = it }, label = { Text("ID da voz") }, singleLine = true, textStyle = TextStyle(color = Color.White), colors = fieldColors) }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Responder usando voz", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = voiceEnabled, onCheckedChange = { voiceEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f))) } }
                item { Text("As chaves ficam salvas somente neste aparelho.", color = Muted, fontSize = 10.sp) }
            }
        }, confirmButton = {
            TextButton(onClick = {
                prefs.edit()
                    .putString("api_key", apiKey.trim())
                    .putString("model", model.trim().ifBlank { Config.DEFAULT_MODEL })
                    .putBoolean("voice", voiceEnabled)
                    .putBoolean("eleven_on", elevenOn)
                    .putString("eleven_key", elevenKey.trim())
                    .putString("voice_id", voiceId.trim().ifBlank { Config.DEFAULT_VOICE_ID })
                    .apply()
                showSettings = false
            }) { Text("SALVAR", color = Cyan) }
        }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("CANCELAR", color = Muted) } })
    }
}

@Composable
private fun HudCore(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "hud")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 3500 else 9000, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "rotation")
    val pulse by transition.animateFloat(.92f, 1.06f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    Canvas(Modifier.size(286.dp).alpha(pulse)) {
        val c = center; val base = size.minDimension / 2f
        drawCircle(Cyan.copy(.035f), radius = base * .95f)
        for (i in 0..5) drawCircle(Cyan.copy(if (i % 2 == 0) .30f else .12f), radius = base * (.42f + i * .085f), style = Stroke(width = if (i == 5) 1.6f else 1f, pathEffect = null))
        drawCircle(Color(0xFF1DAFDC).copy(.10f), radius = base * .34f)
        for (i in 0 until 72) {
            val a = Math.toRadians((i * 5.0 + rotation).toDouble()).toFloat()
            val r1 = base * if (i % 6 == 0) .70f else .76f
            val r2 = base * if (i % 6 == 0) .84f else .80f
            val x1 = c.x + kotlin.math.cos(a) * r1; val y1 = c.y + kotlin.math.sin(a) * r1
            val x2 = c.x + kotlin.math.cos(a) * r2; val y2 = c.y + kotlin.math.sin(a) * r2
            drawLine(Cyan.copy(if (i % 6 == 0) .9f else .42f), androidx.compose.ui.geometry.Offset(x1, y1), androidx.compose.ui.geometry.Offset(x2, y2), strokeWidth = if (i % 6 == 0) 2.4f else 1f, cap = StrokeCap.Round)
        }
        for (i in 0 until 3) {
            val start = rotation + i * 120f
            drawArc(Cyan.copy(.7f), start, 45f, false, topLeft = androidx.compose.ui.geometry.Offset(c.x - base * (.88f - i * .07f), c.y - base * (.88f - i * .07f)), size = androidx.compose.ui.geometry.Size(base * (1.76f - i * .14f), base * (1.76f - i * .14f)), style = Stroke(width = 2.2f, cap = StrokeCap.Round))
        }
        drawCircle(Cyan.copy(.20f), radius = base * .26f)
        drawCircle(Cyan.copy(.9f), radius = base * .19f, style = Stroke(width = 2f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFB9F8FF), Color(0xFF21BDEB), Color(0xFF075078))), radius = base * .135f)
        drawCircle(Color.White.copy(.7f), radius = base * .035f)
    }
}

