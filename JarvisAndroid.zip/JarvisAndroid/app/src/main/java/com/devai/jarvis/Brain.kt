package com.devai.jarvis

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean, val system: Boolean = false, val api: String? = null)

data class Attachment(val name: String, val mime: String, val base64: String)

object Brain {
    val messages = mutableStateListOf(greeting())
    val sessions = mutableStateListOf<ChatSession>()
    var currentId by mutableStateOf(newId())
    private var loaded = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var stopFlag = false

    private fun greeting() = ChatMessage("Olá. Eu sou o JARVIS. Como posso ajudar?", false)
    private fun newId() = System.currentTimeMillis().toString()
    var status by mutableStateOf("ONLINE")
    var busy by mutableStateOf(false)

    private val mutex = Mutex()
    private val actionRegex = Regex("\\[\\[\\s*(\\w+)\\s*(?:\\|([^\\]]*))?\\]\\]")
    private val infoActions = setOf("battery", "location", "notifications", "contact", "read_screen", "sms_read", "calllog", "agenda", "clipboard_get")

    private fun ensureLoaded(ctx: Context) {
        if (!loaded) {
            sessions.addAll(ChatStore.load(ctx.applicationContext))
            loaded = true
        }
    }

    fun init(ctx: Context) = ensureLoaded(ctx)

    /** Interrompe a resposta em andamento e o agente (botão parar). */
    fun requestStop() {
        stopFlag = true
        Agent.stopRequested = true
    }

    fun submit(ctx: Context, text: String, modelText: String = text, files: List<Attachment> = emptyList()) {
        scope.launch { process(ctx, text, modelText, files) }
    }

    fun newChat(ctx: Context) {
        if (busy) return
        ensureLoaded(ctx)
        persist(ctx)
        currentId = newId()
        messages.clear()
        messages.add(greeting())
    }

    fun openChat(ctx: Context, id: String) {
        if (busy) return
        ensureLoaded(ctx)
        persist(ctx)
        val session = sessions.find { it.id == id } ?: return
        currentId = id
        messages.clear()
        messages.addAll(session.messages)
    }

    private fun persist(ctx: Context) {
        val real = messages.toList()
        if (real.none { it.fromUser }) return
        val title = real.first { it.fromUser }.text.lineSequence().first().take(40).ifBlank { "Conversa" }
        val session = ChatSession(currentId, title, real, System.currentTimeMillis())
        val idx = sessions.indexOfFirst { it.id == currentId }
        if (idx >= 0) sessions[idx] = session else sessions.add(0, session)
        ChatStore.save(ctx.applicationContext, sessions.toList())
    }

    suspend fun process(ctx: Context, text: String, modelText: String = text, files: List<Attachment> = emptyList()) = mutex.withLock {
        val app = ctx.applicationContext
        ensureLoaded(app)
        val actions = Actions(app)
        stopFlag = false
        messages.add(ChatMessage(text, true, false, modelText))
        busy = true
        status = "PENSANDO"
        var spoken = ""
        val key = Config.geminiKey(app)
        if (key.isBlank()) {
            val lower = modelText.lowercase(Locale.ROOT)
            val local = when {
                lower.startsWith("abrir ") || lower.startsWith("abra ") || lower.startsWith("abre ") -> actions.run("open_app", modelText.substringAfter(' ').trim())
                lower.contains("que horas") || lower.contains("horário") -> "Agora são ${SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())}."
                else -> "Configure sua chave API do Gemini nas configurações para eu executar qualquer comando."
            }
            messages.add(ChatMessage(local, false))
            spoken = local
        } else {
            val model = Config.model(app)
            val history = messages.filter { !it.system }.takeLast(14).dropWhile { !it.fromUser }
            val image = if (ScreenShare.active) ScreenShare.frameBase64() else null
            val idx = messages.size
            messages.add(ChatMessage("…", false))
            val raw = try {
                callGeminiStream(history, key, model, image, files) { partial ->
                    withContext(Dispatchers.Main) {
                        if (idx < messages.size) messages[idx] = ChatMessage(partial.replace(actionRegex, "").trim(), false)
                    }
                }
            } catch (e: Exception) {
                "Não consegui acessar o Gemini: ${e.message ?: "erro de conexão"}. Verifique sua API Key e sua internet."
            }
            val found = actionRegex.findAll(raw).toList()
            var clean = raw.replace(actionRegex, "").trim()
            if (stopFlag) clean = (clean + "\n\n(resposta interrompida)").trim()
            if (idx < messages.size) {
                if (clean.isNotBlank()) messages[idx] = ChatMessage(clean, false) else messages.removeAt(idx)
            }
            val results = mutableListOf<String>()
            val infos = mutableListOf<String>()
            var agentReply: String? = null
            for (m in found) {
                val name = m.groupValues[1].lowercase(Locale.ROOT)
                if (name == "agent") {
                    val goal = m.groupValues[2].trim()
                    messages.add(ChatMessage("▸ Iniciando tarefa: $goal", false, true))
                    val report = Agent.run(app, goal, key, model)
                    messages.add(ChatMessage(report, false))
                    agentReply = report
                    continue
                }
                val result = actions.run(name, m.groupValues[2])
                results += result
                if (name in infoActions) infos += "$name: $result"
                else messages.add(ChatMessage("▸ $result", false, true))
            }
            spoken = if (clean.isNotBlank()) clean else results.joinToString(" ")
            agentReply?.let { spoken = it }
            if (infos.isNotEmpty()) {
                val followUp = history + ChatMessage(clean.ifBlank { "Executando." }, false) + ChatMessage(
                    "Resultados das ações executadas:\n${infos.joinToString("\n")}\nResponda ao usuário de forma natural e curta usando esses resultados. Não use tags.",
                    true
                )
                val answer = try {
                    callGemini(followUp, key, model, null).replace(actionRegex, "").trim()
                } catch (e: Exception) {
                    infos.joinToString("\n")
                }
                messages.add(ChatMessage(answer, false))
                spoken = answer
            }
        }
        busy = false
        status = "ONLINE"
        persist(app)
        if (Config.voiceEnabled(app) && spoken.isNotBlank()) Voice.speak(app, spoken)
    }

    private const val SYSTEM_PROMPT = """Você é JARVIS, um assistente pessoal que controla este celular Android. Responda em português brasileiro, curto, natural e direto.
Para executar ações no aparelho, inclua tags no fim da resposta no formato [[nome|argumento]]. Use apenas quando o usuário pedir a ação. Você pode usar várias tags na ordem desejada.
Ações disponíveis:
[[open_app|nome do app]] abre um aplicativo
[[call|nome ou número]] liga
[[end_call|]] desliga a ligação
[[answer_call|]] atende a ligação
[[sms|nome ou número;mensagem]] envia SMS
[[sms_read|]] lê os últimos SMS
[[calllog|]] lê as últimas chamadas
[[whatsapp|nome ou número;mensagem]] abre o WhatsApp e envia a mensagem
[[contact|nome]] busca número de contato
[[flashlight|on]] ou [[flashlight|off]] lanterna
[[volume|up]] [[volume|down]] [[volume|mute]] [[volume|max]] ou [[volume|0 a 100]]
[[brightness|0 a 100]] brilho da tela
[[dnd|on]] ou [[dnd|off]] não perturbe
[[vibrate|]] vibra o aparelho
[[alarm|HH:mm;rótulo]] cria alarme
[[timer|segundos]] cria timer
[[calendar|título]] cria evento na agenda
[[agenda|]] lê os compromissos das próximas 24 horas
[[search|consulta]] pesquisa na web
[[maps|destino]] navegação
[[music|música ou artista]] toca música
[[media|play_pause]] [[media|next]] [[media|previous]] [[media|stop]] controla a reprodução atual
[[camera|photo]] abre a câmera
[[battery|]] nível da bateria
[[location|]] localização atual
[[notifications|]] lê as notificações recentes
[[clipboard_get|]] lê a área de transferência
[[clipboard_set|texto]] copia um texto
[[share|texto]] abre o compartilhamento do Android
[[url|endereço]] abre um site
[[settings|wifi]] também bluetooth, display, sound, battery, apps, location, nfc, airplane, date
[[global|home]] [[global|back]] [[global|recents]] [[global|notifications]] [[global|quick_settings]] [[global|screenshot]] [[global|lock]] [[global|power]]
[[read_screen|]] lê o texto que está na tela agora
[[click|texto do botão]] toca em um elemento da tela pelo texto
[[type|texto]] digita no campo selecionado
[[scroll|down]] ou [[scroll|up]] rola a tela
[[swipe|left]] [[swipe|right]] [[swipe|up]] [[swipe|down]] desliza na tela
[[tap|x;y]] toca em uma posição da tela, x e y de 0 a 100 em porcentagem
[[screen_share|on]] ou [[screen_share|off]] liga ou desliga o compartilhamento de tela
[[bubble|on]] ou [[bubble|off]] liga ou desliga a bolinha flutuante
[[agent|objetivo]] executa sozinho uma tarefa de vários passos na tela, como abrir um app, navegar, preencher e enviar. Use quando o pedido exigir operar o celular em sequência. Para uma única ação use a tag direta.
Quando o compartilhamento de tela está ativo, você recebe uma imagem da tela atual junto com a mensagem e pode descrevê-la e responder sobre ela.
Nunca diga que uma ação foi feita sem usar a tag correspondente. Se o pedido não couber nas ações, explique a limitação."""

    private fun buildBody(history: List<ChatMessage>, image: String?, files: List<Attachment>, system: String, json: Boolean): JSONObject {
        val now = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
        val contents = JSONArray()
        history.forEachIndexed { index, m ->
            val parts = JSONArray().put(JSONObject().put("text", m.api ?: m.text))
            if (index == history.lastIndex && m.fromUser) {
                if (image != null) parts.put(inline("image/jpeg", image))
                files.forEach { parts.put(inline(it.mime, it.base64)) }
            }
            contents.put(JSONObject().put("role", if (m.fromUser) "user" else "model").put("parts", parts))
        }
        val generation = JSONObject().put("temperature", 0.6).put("maxOutputTokens", if (json) 600 else 4096)
        if (json) generation.put("responseMimeType", "application/json")
        return JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "$system\nData e hora atuais: $now."))))
            .put("contents", contents)
            .put("generationConfig", generation)
    }

    private fun inline(mime: String, data: String): JSONObject =
        JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", data))

    /** Extrai o texto de um trecho de resposta do Gemini (candidates[0].content.parts). */
    private fun textOf(payload: String): String {
        if (payload.isBlank()) return ""
        val parts = try {
            JSONObject(payload).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        } catch (e: Exception) {
            null
        } ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString()
    }

    private fun open(url: URL, body: JSONObject): HttpURLConnection {
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 90000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun errorMessage(conn: HttpURLConnection, code: Int): String {
        val body = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        return try {
            JSONObject(body).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
        } catch (e: Exception) {
            "HTTP $code"
        }
    }

    /** Resposta em stream: envia cada pedaço ao chat conforme chega. */
    private suspend fun callGeminiStream(
        history: List<ChatMessage>,
        key: String,
        model: String,
        image: String?,
        files: List<Attachment>,
        onPartial: suspend (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:streamGenerateContent?alt=sse&key=${Uri.encode(key)}")
        val conn = open(url, buildBody(history, image, files, SYSTEM_PROMPT, false))
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException(errorMessage(conn, code))
            val sb = StringBuilder()
            conn.inputStream.bufferedReader().use { reader ->
                while (!stopFlag) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val chunk = textOf(line.removePrefix("data:").trim())
                    if (chunk.isNotEmpty()) {
                        sb.append(chunk)
                        onPartial(sb.toString())
                    }
                }
            }
            sb.toString().ifBlank { "Não recebi uma resposta válida do Gemini." }
        } finally {
            conn.disconnect()
        }
    }

    /** Resposta única (sem stream), usada pelo agente e pela confirmação de ações. */
    suspend fun callGemini(
        history: List<ChatMessage>,
        key: String,
        model: String,
        imageBase64: String?,
        system: String = SYSTEM_PROMPT,
        json: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent?key=${Uri.encode(key)}")
        val conn = open(url, buildBody(history, imageBase64, emptyList(), system, json))
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException(errorMessage(conn, code))
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            textOf(body).ifBlank { "Não recebi uma resposta válida do Gemini." }
        } finally {
            conn.disconnect()
        }
    }
}
