package com.devai.jarvis

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean, val system: Boolean = false)

object Brain {
    val messages = mutableStateListOf(ChatMessage("Olá. Eu sou o JARVIS. Como posso ajudar?", false))
    var status by mutableStateOf("ONLINE")
    var busy by mutableStateOf(false)

    private val mutex = Mutex()
    private val actionRegex = Regex("\\[\\[\\s*(\\w+)\\s*(?:\\|([^\\]]*))?\\]\\]")
    private val infoActions = setOf("battery", "location", "notifications", "contact", "read_screen", "sms_read", "calllog", "agenda", "clipboard_get")

    suspend fun process(ctx: Context, text: String) = mutex.withLock {
        val app = ctx.applicationContext
        val actions = Actions(app)
        messages.add(ChatMessage(text, true))
        busy = true
        status = "PENSANDO"
        var spoken: String
        val key = Config.geminiKey(app)
        if (key.isBlank()) {
            val lower = text.lowercase(Locale.ROOT)
            val local = when {
                lower.startsWith("abrir ") || lower.startsWith("abra ") || lower.startsWith("abre ") -> actions.run("open_app", text.substringAfter(' ').trim())
                lower.contains("que horas") || lower.contains("horário") -> "Agora são ${SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())}."
                else -> "Configure sua chave API do Gemini nas configurações para eu executar qualquer comando."
            }
            messages.add(ChatMessage(local, false))
            spoken = local
        } else {
            val model = Config.model(app)
            val history = messages.filter { !it.system }.takeLast(14).dropWhile { !it.fromUser }
            val image = if (ScreenShare.active) ScreenShare.frameBase64() else null
            val raw = try {
                callGemini(history, key, model, image)
            } catch (e: Exception) {
                "Não consegui acessar o Gemini: ${e.message ?: "erro de conexão"}. Verifique sua API Key e sua internet."
            }
            val found = actionRegex.findAll(raw).toList()
            val clean = raw.replace(actionRegex, "").trim()
            if (clean.isNotBlank()) messages.add(ChatMessage(clean, false))
            val results = mutableListOf<String>()
            val infos = mutableListOf<String>()
            for (m in found) {
                val name = m.groupValues[1].lowercase(Locale.ROOT)
                val result = actions.run(name, m.groupValues[2])
                results += result
                if (name in infoActions) infos += "$name: $result"
                else messages.add(ChatMessage("▸ $result", false, true))
            }
            spoken = if (clean.isNotBlank()) clean else results.joinToString(" ")
            if (infos.isNotEmpty()) {
                val followUp = history + ChatMessage(clean.ifBlank { "Executando." }, false) + ChatMessage("Resultados das ações executadas:\n${infos.joinToString("\n")}\nResponda ao usuário de forma natural e curta usando esses resultados. Não use tags.", true)
                val answer = try {
                    callGemini(followUp, key, model, null).replace(actionRegex, "").trim()
                } catch (e: Exception) {
                    infos.joinToString("\n")
                }
                messages.add(ChatMessage(answer, false))
                spoken = answer
            }
        }
        busy = false
        status = "ONLINE"
        if (Config.voiceEnabled(app) && spoken.isNotBlank()) Voice.speak(app, spoken)
    }

    private const val SYSTEM_PROMPT = """Você é JARVIS, um assistente pessoal que controla este celular Android. Responda em português brasileiro, curto, natural e direto.
Para executar ações no aparelho, inclua tags no fim da resposta no formato [[nome|argumento]]. Use apenas quando o usuário pedir a ação. Você pode usar várias tags na ordem desejada.
Ações disponíveis:
[[open_app|nome do app]] abre um aplicativo
[[call|nome ou número]] liga
[[end_call|]] desliga a ligação
[[answer_call|]] atende a ligação
[[sms|nome ou número;mensagem]] envia SMS
[[sms_read|]] lê os últimos SMS
[[calllog|]] lê as últimas chamadas
[[whatsapp|nome ou número;mensagem]] abre o WhatsApp e envia a mensagem
[[contact|nome]] busca número de contato
[[flashlight|on]] ou [[flashlight|off]] lanterna
[[volume|up]] [[volume|down]] [[volume|mute]] [[volume|max]] ou [[volume|0 a 100]]
[[brightness|0 a 100]] brilho da tela
[[dnd|on]] ou [[dnd|off]] não perturbe
[[vibrate|]] vibra o aparelho
[[alarm|HH:mm;rótulo]] cria alarme
[[timer|segundos]] cria timer
[[calendar|título]] cria evento na agenda
[[agenda|]] lê os compromissos das próximas 24 horas
[[search|consulta]] pesquisa na web
[[maps|destino]] navegação
[[music|música ou artista]] toca música
[[media|play_pause]] [[media|next]] [[media|previous]] [[media|stop]] controla a reprodução atual
[[camera|photo]] abre a câmera
[[battery|]] nível da bateria
[[location|]] localização atual
[[notifications|]] lê as notificações recentes
[[clipboard_get|]] lê a área de transferência
[[clipboard_set|texto]] copia um texto
[[share|texto]] abre o compartilhamento do Android
[[url|endereço]] abre um site
[[settings|wifi]] também bluetooth, display, sound, battery, apps, location, nfc, airplane, date
[[global|home]] [[global|back]] [[global|recents]] [[global|notifications]] [[global|quick_settings]] [[global|screenshot]] [[global|lock]] [[global|power]]
[[read_screen|]] lê o texto que está na tela agora
[[click|texto do botão]] toca em um elemento da tela pelo texto
[[type|texto]] digita no campo selecionado
[[scroll|down]] ou [[scroll|up]] rola a tela
[[swipe|left]] [[swipe|right]] [[swipe|up]] [[swipe|down]] desliza na tela
[[tap|x;y]] toca em uma posição da tela, x e y de 0 a 100 em porcentagem
[[screen_share|on]] ou [[screen_share|off]] liga ou desliga o compartilhamento de tela
[[bubble|on]] ou [[bubble|off]] liga ou desliga a bolinha flutuante
Quando o compartilhamento de tela está ativo, você recebe uma imagem da tela atual junto com a mensagem e pode descrevê-la e responder sobre ela.
Nunca diga que uma ação foi feita sem usar a tag correspondente. Se o pedido não couber nas ações, explique a limitação."""

    private suspend fun callGemini(history: List<ChatMessage>, key: String, model: String, imageBase64: String?): String = withContext(Dispatchers.IO) {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent?key=${Uri.encode(key)}")
        val now = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
        val contents = JSONArray()
        history.forEachIndexed { index, m ->
            val parts = JSONArray().put(JSONObject().put("text", m.text))
            if (imageBase64 != null && index == history.lastIndex && m.fromUser) {
                parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imageBase64)))
            }
            contents.put(JSONObject().put("role", if (m.fromUser) "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "$SYSTEM_PROMPT\nData e hora atuais: $now."))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.6).put("maxOutputTokens", 900))
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val result = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(result)
            if (code !in 200..299) throw IllegalStateException(json.optJSONObject("error")?.optString("message") ?: "HTTP $code")
            json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                ?.takeIf { it.isNotBlank() } ?: "Não recebi uma resposta válida do Gemini."
        } finally {
            connection.disconnect()
        }
    }
}
