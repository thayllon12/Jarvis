package com.devai.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Indica se o app está na tela. Com o app aberto, o detector de palavra fica quieto. */
object AppState {
    @Volatile
    var visible = false
}

/**
 * Detector de palavra de ativação: "Jarvis", "Hey Jarvis", "Bom dia Jarvis",
 * "Boa noite Jarvis", "Acorda Jarvis". Roda em ciclo dentro do serviço da bolinha,
 * usando o reconhecedor de fala do Android (precisa de internet ou de pacote offline).
 */
class WakeWord(private val ctx: Context, private val onWake: (rest: String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var paused = false

    companion object {
        private val WAKE = Regex("\\bjarvis\\b", RegexOption.IGNORE_CASE)

        /** Texto depois da palavra de ativação, ou null se a fala não tinha "Jarvis". */
        fun extractRest(text: String): String? {
            val m = WAKE.find(text) ?: return null
            return text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', ';', ':')
        }
    }

    fun start() {
        if (running) return
        running = true
        schedule(0)
    }

    fun stop() {
        running = false
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
    }

    fun pause() {
        paused = true
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
    }

    fun resume() {
        if (!paused) return
        paused = false
        if (running) schedule(300)
    }

    private fun schedule(delayMs: Long) {
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ listen() }, delayMs)
    }

    private fun destroyRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun listen() {
        if (!running || paused) return
        if (AppState.visible) {
            schedule(2000)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            running = false
            return
        }
        destroyRecognizer()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                destroyRecognizer()
                val rest = extractRest(text)
                if (rest != null) {
                    paused = true // quem controla a retomada é o serviço, após o comando
                    onWake(rest)
                } else {
                    schedule(200)
                }
            }

            override fun onError(error: Int) {
                destroyRecognizer()
                val delay = when (error) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 2000L
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 10000L
                    else -> 400L
                }
                schedule(delay)
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }
}
