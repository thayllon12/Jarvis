package com.devai.jarvis

import android.content.Context
import android.content.SharedPreferences

object Config {
    const val DEFAULT_VOICE_ID = "hwnuNyWkl9DjdTFykrN6"
    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    const val DEFAULT_LOCAL_URL = "http://127.0.0.1:8080/v1"
    const val DEFAULT_LOCAL_MODEL = "local-model"
    private const val LEGACY_MODEL = "gemini-2.0-flash"

    fun prefs(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    fun geminiKey(ctx: Context): String = prefs(ctx).getString("api_key", "").orEmpty()

    fun model(ctx: Context): String {
        val saved = prefs(ctx).getString("model", DEFAULT_MODEL).orEmpty().trim()
        // Migra quem ainda tem o modelo antigo salvo nas preferências
        return if (saved.isBlank() || saved == LEGACY_MODEL) DEFAULT_MODEL else saved
    }

    fun voiceEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("voice", true)

    fun elevenEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("eleven_on", true)

    fun elevenKey(ctx: Context): String = prefs(ctx).getString("eleven_key", "").orEmpty().ifBlank { BuildConfig.ELEVENLABS_API_KEY }

    fun wakeOn(ctx: Context): Boolean = prefs(ctx).getBoolean("wake_on", true)

    fun localOn(ctx: Context): Boolean = prefs(ctx).getBoolean("local_on", false)

    fun localUrl(ctx: Context): String = prefs(ctx).getString("local_url", DEFAULT_LOCAL_URL).orEmpty().ifBlank { DEFAULT_LOCAL_URL }

    fun localModel(ctx: Context): String = prefs(ctx).getString("local_model", DEFAULT_LOCAL_MODEL).orEmpty().ifBlank { DEFAULT_LOCAL_MODEL }

    fun localKey(ctx: Context): String = prefs(ctx).getString("local_key", "").orEmpty()

    fun hapticTyping(ctx: Context): Boolean = prefs(ctx).getBoolean("haptic_typing", true)

    fun hapticOn(ctx: Context): Boolean = prefs(ctx).getBoolean("haptic_reply", true)

    fun voiceId(ctx: Context): String = prefs(ctx).getString("voice_id", DEFAULT_VOICE_ID).orEmpty().ifBlank { DEFAULT_VOICE_ID }
}
