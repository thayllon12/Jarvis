package com.devai.jarvis

import android.content.Context
import android.content.SharedPreferences

object Config {
    const val DEFAULT_VOICE_ID = "hwnuNyWkl9DjdTFykrN6"
    const val DEFAULT_MODEL = "gemini-2.0-flash"

    fun prefs(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    fun geminiKey(ctx: Context): String = prefs(ctx).getString("api_key", "").orEmpty()

    fun model(ctx: Context): String = prefs(ctx).getString("model", DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }

    fun voiceEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("voice", true)

    fun elevenEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("eleven_on", true)

    fun elevenKey(ctx: Context): String = prefs(ctx).getString("eleven_key", "").orEmpty().ifBlank { BuildConfig.ELEVENLABS_API_KEY }

    fun voiceId(ctx: Context): String = prefs(ctx).getString("voice_id", DEFAULT_VOICE_ID).orEmpty().ifBlank { DEFAULT_VOICE_ID }
}
