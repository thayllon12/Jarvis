package com.devai.jarvis

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream

/** Lê anexos (fotos, PDFs, arquivos de texto) para envio ao Gemini. */
object FileIO {
    data class Picked(val name: String, val attachment: Attachment?, val text: String?)

    private const val MAX_TEXT = 200_000
    private val CODE_EXT = setOf(
        "kt", "java", "py", "js", "ts", "html", "css", "md", "txt", "csv", "json", "xml",
        "gradle", "sh", "yml", "yaml", "c", "cpp", "h", "go", "rs", "php", "sql", "dart", "swift"
    )

    fun pickAll(ctx: Context, uris: List<Uri>): List<Picked> = uris.map { pick(ctx, it) }

    fun pick(ctx: Context, uri: Uri): Picked {
        val name = displayName(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: return Picked(name, null, "\n\n(não consegui ler $name)")
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            mime.startsWith("image/") -> {
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp == null) Picked(name, null, "\n\n(imagem $name não suportada)")
                else Picked(name, Attachment(name, "image/jpeg", encodeBitmap(bmp)), null)
            }
            mime == "application/pdf" && bytes.size <= 15_000_000 ->
                Picked(name, Attachment(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP)), null)
            mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") || mime.contains("javascript") || ext in CODE_EXT -> {
                val text = String(bytes, Charsets.UTF_8).take(MAX_TEXT)
                Picked(name, null, "\n\nArquivo $name:\n```\n$text\n```")
            }
            else -> Picked(name, null, "\n\n(arquivo $name em formato não suportado para leitura)")
        }
    }

    fun fromBitmap(bmp: Bitmap): Picked =
        Picked("foto.jpg", Attachment("foto.jpg", "image/jpeg", encodeBitmap(bmp)), null)

    /** Envia uma mensagem com anexos: o texto visível e o texto enviado ao modelo são separados. */
    fun send(ctx: Context, base: String, picked: List<Picked>) {
        val files = picked.mapNotNull { it.attachment }
        val extra = picked.mapNotNull { it.text }.joinToString("")
        val shown = if (picked.isEmpty()) base else base + "\n📎 " + picked.joinToString(", ") { it.name }
        Brain.submit(ctx, shown, base + extra, files)
    }

    private fun encodeBitmap(bmp: Bitmap): String {
        val max = 1280
        val biggest = maxOf(bmp.width, bmp.height)
        val scale = if (biggest > max) max.toFloat() / biggest else 1f
        val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val os = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 80, os)
        return Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP)
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }
}
