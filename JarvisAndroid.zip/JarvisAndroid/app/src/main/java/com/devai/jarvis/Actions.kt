package com.devai.jarvis

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Geocoder
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.os.VibrationEffect
import android.os.Vibrator
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

class Actions(private val ctx: Context) {

    suspend fun run(name: String, arg: String): String = withContext(Dispatchers.IO) {
        try {
            dispatch(name.lowercase(Locale.ROOT).trim(), arg.trim())
        } catch (e: SecurityException) {
            "Permissão negada para ${name}. Abra o painel de permissões e conceda o acesso."
        } catch (e: Exception) {
            "Falha em ${name}: ${e.message ?: "erro desconhecido"}"
        }
    }

    private fun start(intent: Intent) {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun dispatch(name: String, arg: String): String {
        val parts = arg.split(";").map { it.trim() }
        return when (name) {
            "open_app" -> openApp(arg)
            "call" -> call(arg)
            "sms" -> sms(parts.getOrElse(0) { "" }, parts.drop(1).joinToString(";"))
            "whatsapp" -> whatsapp(parts.getOrElse(0) { "" }, parts.drop(1).joinToString(";"))
            "contact" -> contact(arg)
            "flashlight" -> flashlight(arg)
            "volume" -> volume(arg)
            "brightness" -> brightness(arg)
            "dnd" -> dnd(arg)
            "alarm" -> alarm(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "JARVIS" })
            "timer" -> timer(arg)
            "search" -> search(arg)
            "maps" -> maps(arg)
            "music" -> music(arg)
            "media" -> media(arg)
            "camera" -> camera()
            "battery" -> battery()
            "location" -> location()
            "notifications" -> notifications()
            "global" -> global(arg)
            "url" -> url(arg)
            "calendar" -> calendar(parts.getOrElse(0) { "" })
            "settings" -> settings(arg)
            "read_screen" -> readScreen()
            "click" -> click(arg)
            "type" -> typeText(arg)
            "scroll" -> scroll(arg)
            "swipe" -> swipe(arg)
            "tap" -> tap(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" })
            "screen_share" -> ScreenShare.request(ctx, arg.lowercase(Locale.ROOT) != "off")
            "bubble" -> if (arg.lowercase(Locale.ROOT) == "off") BubbleService.stop(ctx) else BubbleService.start(ctx)
            "sms_read" -> smsRead()
            "calllog" -> callLog()
            "agenda" -> agenda()
            "clipboard_set" -> clipboardSet(arg)
            "clipboard_get" -> clipboardGet()
            "share" -> share(arg)
            "vibrate" -> vibrate()
            "end_call" -> endCall()
            "answer_call" -> answerCall()
            else -> "Ação desconhecida: $name"
        }
    }

    fun openApp(query: String): String {
        val normalized = query.lowercase(Locale.ROOT).trim()
        val aliases = mapOf(
            "youtube" to listOf("youtube"),
            "whatsapp" to listOf("whatsapp"),
            "instagram" to listOf("instagram"),
            "spotify" to listOf("spotify"),
            "lark player" to listOf("lark"),
            "chrome" to listOf("chrome"),
            "câmera" to listOf("camera", "câmera"),
            "galeria" to listOf("gallery", "galeria", "photos", "fotos"),
            "calculadora" to listOf("calculator", "calculadora"),
            "relógio" to listOf("clock", "relógio"),
            "configurações" to listOf("settings", "configurações")
        )
        val terms = aliases[normalized] ?: listOf(normalized)
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val found = apps.firstOrNull { app ->
            pm.getLaunchIntentForPackage(app.packageName) != null && run {
                val label = pm.getApplicationLabel(app).toString().lowercase(Locale.ROOT)
                terms.any { label.contains(it) || app.packageName.lowercase(Locale.ROOT).contains(it) }
            }
        }
        if (found != null) {
            val launch = pm.getLaunchIntentForPackage(found.packageName)
            if (launch != null) {
                start(launch)
                return "Abrindo ${pm.getApplicationLabel(found)}."
            }
        }
        if (normalized.contains("config")) {
            start(Intent(Settings.ACTION_SETTINGS))
            return "Abrindo as configurações do Android."
        }
        return "Não encontrei o aplicativo $query instalado."
    }

    private fun findNumber(who: String): String? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 6) return digits
        if (!Perms.has(ctx, Manifest.permission.READ_CONTACTS)) return null
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$who%"),
            null
        )
        cursor?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun contact(who: String): String {
        if (!Perms.has(ctx, Manifest.permission.READ_CONTACTS)) return "Sem permissão para ler contatos."
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$who%"),
            null
        )
        val result = mutableListOf<String>()
        cursor?.use { while (it.moveToNext() && result.size < 5) result += "${it.getString(0)}: ${it.getString(1)}" }
        return if (result.isEmpty()) "Nenhum contato encontrado para $who." else result.joinToString("\n")
    }

    private fun call(who: String): String {
        val number = findNumber(who) ?: return "Não encontrei o número de $who."
        val uri = Uri.parse("tel:" + Uri.encode(number))
        return if (Perms.has(ctx, Manifest.permission.CALL_PHONE)) {
            start(Intent(Intent.ACTION_CALL, uri))
            "Ligando para $who."
        } else {
            start(Intent(Intent.ACTION_DIAL, uri))
            "Discador aberto para $who."
        }
    }

    private fun sms(who: String, message: String): String {
        val number = findNumber(who) ?: return "Não encontrei o número de $who."
        if (message.isBlank()) return "Mensagem vazia."
        if (!Perms.has(ctx, Manifest.permission.SEND_SMS)) return "Sem permissão para enviar SMS."
        val manager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
        val chunks = manager.divideMessage(message)
        manager.sendMultipartTextMessage(number, null, chunks, null, null)
        return "SMS enviado para $who."
    }

    private fun whatsapp(who: String, message: String): String {
        val number = findNumber(who)?.filter { it.isDigit() } ?: return "Não encontrei o número de $who."
        val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(message))
        start(Intent(Intent.ACTION_VIEW, uri))
        if (JarvisAccessibilityService.instance == null || message.isBlank()) return "Conversa do WhatsApp aberta com $who."
        Thread.sleep(3500)
        val sent = JarvisAccessibilityService.instance?.let { it.clickText("Enviar") || it.clickText("Send") } ?: false
        return if (sent) "Mensagem enviada para $who no WhatsApp." else "Conversa aberta com $who, toque em enviar."
    }

    private fun flashlight(state: String): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "Este aparelho não tem lanterna."
        val on = !state.lowercase(Locale.ROOT).let { it == "off" || it == "desligar" }
        cm.setTorchMode(id, on)
        return if (on) "Lanterna ligada." else "Lanterna desligada."
    }

    private fun volume(value: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val v = value.lowercase(Locale.ROOT).trim()
        when {
            v == "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            v == "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            v == "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            v == "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
            else -> {
                val pct = v.toIntOrNull() ?: return "Volume inválido."
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (pct.coerceIn(0, 100) * max) / 100, AudioManager.FLAG_SHOW_UI)
            }
        }
        return "Volume ajustado."
    }

    private fun brightness(value: String): String {
        if (!Settings.System.canWrite(ctx)) return "Conceda o acesso 'Modificar configurações do sistema' no painel de permissões."
        val pct = value.toIntOrNull() ?: return "Brilho inválido."
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (pct.coerceIn(0, 100) * 255) / 100)
        return "Brilho em ${pct.coerceIn(0, 100)}%."
    }

    private fun dnd(state: String): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return "Conceda o acesso 'Não perturbe' no painel de permissões."
        val on = state.lowercase(Locale.ROOT) != "off"
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (on) "Não perturbe ativado." else "Não perturbe desativado."
    }

    private fun alarm(time: String, label: String): String {
        val hm = time.split(":")
        val h = hm.getOrNull(0)?.trim()?.toIntOrNull() ?: return "Horário inválido."
        val m = hm.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
        start(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Alarme definido para %02d:%02d.".format(h, m)
    }

    private fun timer(seconds: String): String {
        val s = seconds.toIntOrNull() ?: return "Duração inválida."
        start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer de $s segundos iniciado."
    }

    private fun search(query: String): String {
        start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query))
        return "Pesquisando: $query."
    }

    private fun maps(destination: String): String {
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination)))
        return try {
            start(nav)
            "Navegando para $destination."
        } catch (e: Exception) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(destination))))
            "Abrindo $destination no mapa."
        }
    }

    private fun music(query: String): String {
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
        return try {
            start(intent)
            "Tocando $query."
        } catch (e: Exception) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))))
            "Buscando $query no YouTube."
        }
    }

    private fun media(command: String): String {
        val code = when (command.lowercase(Locale.ROOT)) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Controle de mídia enviado."
    }

    private fun camera(): String {
        start(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        return "Câmera aberta."
    }

    private fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return "Bateria em $level%${if (charging) ", carregando" else ""}."
    }

    private fun location(): String {
        if (!Perms.has(ctx, Manifest.permission.ACCESS_FINE_LOCATION) && !Perms.has(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)) return "Sem permissão de localização."
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
            .maxByOrNull { it.time } ?: return "Não consegui obter a localização. Ative o GPS."
        val address = try {
            @Suppress("DEPRECATION")
            Geocoder(ctx, Locale("pt", "BR")).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()?.getAddressLine(0)
        } catch (e: Exception) {
            null
        }
        return "Localização: ${address ?: "%.5f, %.5f".format(loc.latitude, loc.longitude)}."
    }

    private fun notifications(): String {
        if (JarvisNotificationListener.recent.isEmpty()) return "Nenhuma notificação registrada. Verifique se o acesso a notificações está ativo."
        return JarvisNotificationListener.recent.take(8).joinToString("\n")
    }

    private fun global(command: String): String {
        val action = when (command.lowercase(Locale.ROOT)) {
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "power" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return "Bloqueio exige Android 9 ou superior."
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return "Captura exige Android 9 ou superior."
            else -> return "Comando global desconhecido."
        }
        return if (JarvisAccessibilityService.perform(action)) "Feito." else "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
    }

    private fun url(address: String): String {
        val u = if (address.startsWith("http")) address else "https://$address"
        start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        return "Abrindo $u."
    }

    private fun calendar(title: String): String {
        start(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, title))
        return "Criando evento: $title."
    }

    private fun needAccessibility(): JarvisAccessibilityService? = JarvisAccessibilityService.instance

    private fun readScreen(): String {
        val svc = needAccessibility() ?: return "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
        return svc.readScreen().ifBlank { "Não encontrei texto na tela." }.take(3000)
    }

    private fun click(text: String): String {
        val svc = needAccessibility() ?: return "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
        return if (svc.clickText(text)) "Toquei em $text." else "Não achei '$text' na tela."
    }

    private fun typeText(text: String): String {
        val svc = needAccessibility() ?: return "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
        return if (svc.typeText(text)) "Texto digitado." else "Não encontrei um campo de texto."
    }

    private fun scroll(direction: String): String {
        val svc = needAccessibility() ?: return "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
        return if (svc.scroll(direction.lowercase(Locale.ROOT) != "up")) "Rolando a tela." else "Não encontrei conteúdo para rolar."
    }

    private fun swipe(direction: String): String {
        val svc = needAccessibility() ?: return "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
        val m = ctx.resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val ok = when (direction.lowercase(Locale.ROOT)) {
            "left" -> svc.gesture(w * .8f, h * .5f, w * .2f, h * .5f, 250)
            "right" -> svc.gesture(w * .2f, h * .5f, w * .8f, h * .5f, 250)
            "up" -> svc.gesture(w * .5f, h * .75f, w * .5f, h * .25f, 250)
            "down" -> svc.gesture(w * .5f, h * .25f, w * .5f, h * .75f, 250)
            else -> false
        }
        return if (ok) "Deslizei a tela." else "Não consegui deslizar."
    }

    private fun tap(xs: String, ys: String): String {
        val svc = needAccessibility() ?: return "Ative o serviço de acessibilidade do JARVIS no painel de permissões."
        val x = xs.toFloatOrNull() ?: return "Posição inválida."
        val y = ys.toFloatOrNull() ?: return "Posição inválida."
        val m = ctx.resources.displayMetrics
        val ok = svc.gesture(m.widthPixels * x / 100f, m.heightPixels * y / 100f, m.widthPixels * x / 100f, m.heightPixels * y / 100f, 60)
        return if (ok) "Toque realizado." else "Não consegui tocar."
    }

    private fun smsRead(): String {
        if (!Perms.has(ctx, Manifest.permission.READ_SMS)) return "Sem permissão para ler SMS."
        val cursor = ctx.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC")
        val list = mutableListOf<String>()
        cursor?.use { while (it.moveToNext() && list.size < 5) list += "${it.getString(0)}: ${it.getString(1).take(160)}" }
        return if (list.isEmpty()) "Nenhum SMS encontrado." else list.joinToString("\n")
    }

    private fun callLog(): String {
        if (!Perms.has(ctx, Manifest.permission.READ_CALL_LOG)) return "Sem permissão para ler o histórico de chamadas."
        val cursor = ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE), null, null, "${CallLog.Calls.DATE} DESC")
        val list = mutableListOf<String>()
        cursor?.use {
            while (it.moveToNext() && list.size < 6) {
                val kind = when (it.getInt(2)) { CallLog.Calls.MISSED_TYPE -> "perdida"; CallLog.Calls.OUTGOING_TYPE -> "feita"; CallLog.Calls.INCOMING_TYPE -> "recebida"; else -> "outra" }
                list += "${it.getString(1) ?: it.getString(0)} ($kind)"
            }
        }
        return if (list.isEmpty()) "Nenhuma chamada encontrada." else list.joinToString("\n")
    }

    private fun agenda(): String {
        if (!Perms.has(ctx, Manifest.permission.READ_CALENDAR)) return "Sem permissão para ler a agenda."
        val now = System.currentTimeMillis()
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, now)
        ContentUris.appendId(builder, now + 24L * 3600L * 1000L)
        val cursor = ctx.contentResolver.query(builder.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), null, null, "begin ASC")
        val list = mutableListOf<String>()
        val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR"))
        cursor?.use { while (it.moveToNext() && list.size < 8) list += "${fmt.format(java.util.Date(it.getLong(1)))} ${it.getString(0)}" }
        return if (list.isEmpty()) "Nenhum compromisso nas próximas 24 horas." else list.joinToString("\n")
    }

    private fun clipboardSet(text: String): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("JARVIS", text))
        return "Texto copiado."
    }

    private fun clipboardGet(): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
        return text.ifBlank { "A área de transferência está vazia ou o Android bloqueou a leitura em segundo plano." }
    }

    private fun share(text: String): String {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        start(Intent.createChooser(send, "Compartilhar"))
        return "Compartilhamento aberto."
    }

    private fun vibrate(): String {
        val v = ctx.getSystemService(Vibrator::class.java)
        v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
        return "Vibrando."
    }

    private fun endCall(): String {
        if (Build.VERSION.SDK_INT < 28) return "Encerrar chamada exige Android 9 ou superior."
        val tm = ctx.getSystemService(TelecomManager::class.java)
        return if (tm.endCall()) "Chamada encerrada." else "Não há chamada para encerrar."
    }

    private fun answerCall(): String {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.acceptRingingCall()
        return "Atendendo a chamada."
    }

    private fun settings(page: String): String {
        val action = when (page.lowercase(Locale.ROOT)) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action))
        return "Abrindo configurações."
    }
}
