package com.devai.jarvis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Tela transparente aberta pela bolinha para tirar foto ou escolher arquivo. */
class QuickPickActivity : ComponentActivity() {
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) {
            lifecycleScope.launch {
                val picked = withContext(Dispatchers.IO) { FileIO.fromBitmap(bmp) }
                FileIO.send(applicationContext, "Veja esta foto e me diga o que você vê.", listOf(picked))
            }
        }
        finish()
    }

    private val files = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            lifecycleScope.launch {
                val picked = withContext(Dispatchers.IO) { FileIO.pickAll(applicationContext, uris) }
                FileIO.send(applicationContext, "Analise o(s) arquivo(s).", picked)
            }
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent.getStringExtra("mode")) {
            "camera" -> camera.launch(null)
            else -> files.launch("*/*")
        }
    }
}
