package com.devai.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Voz exclusivamente pela ElevenLabs. Se ela falhar, não há substituto silencioso:
 * o motivo fica em lastError e aparece no chat.
 */
object Voice {
    private const val TAG = "JarvisVoice"

    /** Motivo da última falha da ElevenLabs (vazio = ok). */
    var lastError by mutableStateOf("")

    private var player: MediaPlayer? = null

    suspend fun speak(ctx: Context, text: String) {
        val app = ctx.applicationContext
        val clean = text.replace(Regex("[*_`#]"), "").trim().take(900)
        if (clean.isBlank()) return
        stop()
        if (!Config.elevenEnabled(app)) {
            lastError = ""
            return
        }
        val key = Config.elevenKey(app)
        if (key.isBlank()) {
            lastError = "chave da ElevenLabs não configurada"
            Log.w(TAG, lastError)
            return
        }
        try {
            val file = fetch(app, clean, key, Config.voiceId(app))
            play(file)
            lastError = ""
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            Log.e(TAG, "ElevenLabs falhou", e)
        }
    }

    fun stop() {
        try { player?.release() } catch (e: Exception) {}
        player = null
    }

    private suspend fun fetch(ctx: Context, text: String, key: String, voiceId: String): File = withContext(Dispatchers.IO) {
        val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
        val body = JSONObject()
            .put("text", text)
            .put("model_id", "eleven_multilingual_v2")
            .put("voice_settings", JSONObject().put("stability", 0.5).put("similarity_boost", 0.8))
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "audio/mpeg")
            setRequestProperty("xi-api-key", key)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty().take(160)
                throw IllegalStateException("ElevenLabs indisponível (HTTP $code) $err".trim())
            }
            val file = File(ctx.cacheDir, "jarvis_voice_${System.currentTimeMillis()}.mp3")
            conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
            file
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun play(file: File) = withContext(Dispatchers.Main) {
        val mp = MediaPlayer()
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        mp.setDataSource(file.absolutePath)
        mp.setOnCompletionListener {
            it.release()
            if (player === it) player = null
            file.delete()
        }
        mp.setOnErrorListener { m, _, _ ->
            m.release()
            if (player === m) player = null
            true
        }
        mp.prepare()
        player = mp
        mp.start()
    }
}
