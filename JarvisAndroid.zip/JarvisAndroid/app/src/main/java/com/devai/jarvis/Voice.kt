package com.devai.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object Voice {
    private const val TAG = "JarvisVoice"
    /** Último motivo de falha do ElevenLabs (vazio = ok). Exibido na UI. */
    var lastError by mutableStateOf("")

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null

    private fun ensureTts(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                ttsReady = true
            }
        }
    }

    suspend fun speak(ctx: Context, text: String) {
        val app = ctx.applicationContext
        val clean = text.replace(Regex("[*_`#]"), "").trim().take(900)
        if (clean.isBlank()) return
        stop()
        val key = Config.elevenKey(app)
        if (!Config.elevenEnabled(app)) {
            lastError = "ElevenLabs desativado nas configurações"
        } else if (key.isBlank()) {
            // Causa mais comum: o build do GitHub não recebeu o secret ELEVENLABS_API_KEY
            lastError = "Sem chave ElevenLabs no app (secret do GitHub ausente ou vazio)"
            Log.w(TAG, lastError)
        } else {
            try {
                val file = fetch(app, clean, key, Config.voiceId(app))
                play(file)
                lastError = ""
                return
            } catch (e: Exception) {
                lastError = "ElevenLabs falhou: ${e.message ?: e.javaClass.simpleName}"
                Log.e(TAG, lastError, e)
            }
        }
        withContext(Dispatchers.Main) {
            ensureTts(app)
            tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    fun stop() {
        try { player?.release() } catch (e: Exception) {}
        player = null
        tts?.stop()
    }

    private suspend fun fetch(ctx: Context, text: String, key: String, voiceId: String): File = withContext(Dispatchers.IO) {
        val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
        val body = JSONObject()
            .put("text", text)
            .put("model_id", "eleven_multilingual_v2")
            .put("voice_settings", JSONObject().put("stability", 0.5).put("similarity_boost", 0.8))
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "audio/mpeg")
            setRequestProperty("xi-api-key", key)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = (conn.errorStream?.bufferedReader()?.use { it.readText() }).orEmpty().take(200)
                throw IllegalStateException("HTTP $code ${err}".trim())
            }
            val file = File(ctx.cacheDir, "jarvis_voice_${System.currentTimeMillis()}.mp3")
            conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
            file
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun play(file: File) = withContext(Dispatchers.Main) {
        val mp = MediaPlayer()
        mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        mp.setDataSource(file.absolutePath)
        mp.setOnCompletionListener {
            it.release()
            if (player === it) player = null
            file.delete()
        }
        mp.setOnErrorListener { m, _, _ ->
            m.release()
            if (player === m) player = null
            true
        }
        mp.prepare()
        player = mp
        mp.start()
    }
}
