package com.devai.jarvis

import android.Manifest
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/** Bolinha: cinza-clara em repouso, verde ao ouvir, âmbar ao responder. */
class OrbView(context: Context) : View(context) {
    var state = 0
        set(value) {
            field = value
            invalidate()
        }
    private var angle = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val c = when (state) {
            1 -> Color.parseColor("#4CE08A")
            2 -> Color.parseColor("#FFC45B")
            else -> Color.parseColor("#E6EEF5")
        }
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 6f
        fill.color = Color.parseColor("#E6101418")
        canvas.drawCircle(cx, cy, r, fill)
        ring.color = c
        ring.alpha = 255
        canvas.drawCircle(cx, cy, r, ring)
        ring.alpha = 150
        val box = RectF(cx - r * .72f, cy - r * .72f, cx + r * .72f, cy + r * .72f)
        canvas.drawArc(box, angle, 70f, false, ring)
        canvas.drawArc(box, angle + 180f, 70f, false, ring)
        fill.color = c
        fill.alpha = 60
        canvas.drawCircle(cx, cy, r * .38f, fill)
        fill.alpha = 255
        fill.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .14f, fill)
    }
}

/**
 * Bolinha flutuante no estilo do Gemini.
 * Toque: expande a barra (câmera, compartilhar tela | microfone, fechar).
 * Arrastar: move. Segurar: abre o app.
 */
class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var orb: OrbView? = null
    private var root: LinearLayout? = null
    private var leftBar: LinearLayout? = null
    private var rightBar: LinearLayout? = null
    private var micButton: ImageButton? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false
    private var orbPx = 0
    private var barPx = 0
    private var input: VoiceInput? = null
    private var wake: WakeWord? = null
    private var commanding = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_WAKE) {
            applyWake()
            return START_STICKY
        }
        startInForeground()
        if (orb == null) addOrb()
        running = true
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Bolinha do JARVIS", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("JARVIS ativo")
            .setContentText("Diga \"Jarvis\" ou toque na bolinha")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Desligar", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, notification)
    }

    private fun addOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dp = resources.displayMetrics.density
        orbPx = (60 * dp).toInt()
        val btnPx = (46 * dp).toInt()
        val gapPx = (8 * dp).toInt()
        barPx = 2 * (btnPx + gapPx)
        val view = OrbView(this)

        fun bar(icon: Int, label: String, onTap: () -> Unit): ImageButton {
            val pad = (12 * dp).toInt()
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E6101418"))
            }
            return ImageButton(this).apply {
                setImageResource(icon)
                background = bg
                setColorFilter(Color.parseColor("#F2F5F8"))
                contentDescription = label
                setPadding(pad, pad, pad, pad)
                setOnClickListener { onTap() }
            }
        }
        fun lp() = LinearLayout.LayoutParams((46 * dp).toInt(), (46 * dp).toInt()).apply {
            leftMargin = (4 * dp).toInt()
            rightMargin = (4 * dp).toInt()
        }

        val left = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        val right = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        left.addView(bar(android.R.drawable.ic_menu_camera, "Câmera") { setExpanded(false); openQuick("camera") }, lp())
        left.addView(bar(android.R.drawable.ic_menu_share, "Compartilhar tela") {
            Toast.makeText(this, ScreenShare.request(this, !ScreenShare.active), Toast.LENGTH_SHORT).show()
        }, lp())
        val mic = bar(android.R.drawable.ic_btn_speak_now, "Microfone") { toggleListening() }
        micButton = mic
        right.addView(mic, lp())
        right.addView(bar(android.R.drawable.ic_menu_close_clear_cancel, "Fechar") { setExpanded(false) }, lp())
        leftBar = left
        rightBar = right

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(left, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(view, LinearLayout.LayoutParams(orbPx, orbPx))
        row.addView(right, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val lparams = WindowManager.LayoutParams(
            orbPx, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - orbPx - 16
            y = resources.displayMetrics.heightPixels / 3
        }
        params = lparams
        root = row

        input = VoiceInput(this, onText = { text -> Brain.submit(this, text) }, onEnd = { ok ->
            commanding = false
            micTint(false)
            if (!ok) {
                orb?.state = 0
                wake?.resume()
            }
        })
        wake = WakeWord(this) { rest -> onWakeWord(rest) }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var downAt = 0L
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lparams.x
                    startY = lparams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    downAt = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved && !expanded) {
                        lparams.x = startX + dx
                        lparams.y = startY + dy
                        wm.updateViewLayout(row, lparams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (System.currentTimeMillis() - downAt > 600) openApp()
                        else setExpanded(!expanded)
                    }
                    true
                }
                else -> false
            }
        }

        // Estado da bolinha acompanha o processamento; o wake word pausa durante a resposta.
        scope.launch {
            snapshotFlow { Brain.busy }.collect { busy ->
                orb?.state = if (busy) 2 else if (commanding) 1 else 0
                if (busy) wake?.pause() else if (!commanding) wake?.resume()
            }
        }

        wm.addView(row, lparams)
        orb = view
        applyWake()
    }

    /** Expande para os dois lados mantendo a bolinha no lugar. */
    private fun setExpanded(on: Boolean) {
        val p = params ?: return
        val r = root ?: return
        if (on == expanded) return
        expanded = on
        val vis = if (on) View.VISIBLE else View.GONE
        leftBar?.visibility = vis
        rightBar?.visibility = vis
        val total = orbPx + 2 * barPx
        val screenW = resources.displayMetrics.widthPixels
        val nextX = if (on) p.x - barPx else p.x + barPx
        p.x = nextX.coerceIn(0, maxOf(0, screenW - total))
        p.width = if (on) total else orbPx
        wm.updateViewLayout(r, p)
    }

    private fun toggleListening() {
        if (commanding) cancelListening() else startListening()
    }

    private fun micTint(on: Boolean) {
        micButton?.setColorFilter(Color.parseColor(if (on) "#4CE08A" else "#F2F5F8"))
    }

    private fun startListening() {
        if (!Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "Conceda a permissão de microfone no app primeiro.", Toast.LENGTH_LONG).show()
            return
        }
        commanding = true
        wake?.pause()
        micTint(true)
        orb?.state = 1
        input?.start()
    }

    private fun cancelListening() {
        input?.cancel()
        commanding = false
        micTint(false)
        orb?.state = 0
        wake?.resume()
    }

    /** Palavra "Jarvis" ouvida: abre a barra e executa o pedido ou começa a ouvir. */
    private fun onWakeWord(rest: String) {
        if (!expanded) setExpanded(true)
        if (rest.isNotBlank()) {
            orb?.state = 2
            Brain.submit(this, rest)
        } else {
            startListening()
        }
    }

    private fun applyWake() {
        val w = wake ?: return
        if (Config.wakeOn(this) && Perms.has(this, Manifest.permission.RECORD_AUDIO)) w.start() else w.stop()
    }

    private fun openQuick(mode: String) {
        startActivity(Intent(this, QuickPickActivity::class.java).putExtra("mode", mode).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() {
        running = false
        root?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        root = null
        orb = null
        input?.destroy()
        wake?.stop()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.devai.jarvis.STOP_BUBBLE"
        const val ACTION_WAKE = "com.devai.jarvis.WAKE_REFRESH"
        private const val CHANNEL = "jarvis_bubble"
        private const val NOTIF_ID = 4201

        var running by mutableStateOf(false)

        fun start(ctx: Context): String {
            if (!Settings.canDrawOverlays(ctx)) return "Ative 'Sobrepor outros apps' no painel de permissões."
            if (!Perms.has(ctx, Manifest.permission.RECORD_AUDIO)) return "Conceda a permissão de microfone primeiro."
            ctx.startForegroundService(Intent(ctx, BubbleService::class.java))
            return "Bolinha ativada. Diga \"Jarvis\" ou toque nela."
        }

        /** Aplica a preferência da palavra de ativação sem reiniciar a bolinha. */
        fun refreshWake(ctx: Context) {
            if (running) ctx.startService(Intent(ctx, BubbleService::class.java).setAction(ACTION_WAKE))
        }

        fun stop(ctx: Context): String {
            ctx.startService(Intent(ctx, BubbleService::class.java).setAction(ACTION_STOP))
            return "Bolinha desativada."
        }
    }
}
