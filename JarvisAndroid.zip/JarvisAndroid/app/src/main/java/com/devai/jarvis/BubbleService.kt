package com.devai.jarvis

import android.Manifest
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class OrbView(context: Context) : View(context) {
    var state = 0
        set(value) { field = value; invalidate() }
    private var angle = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val c = when (state) { 1 -> Color.parseColor("#4CE08A"); 2 -> Color.parseColor("#FFC45B"); else -> Color.parseColor("#39D9FF") }
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 6f
        fill.color = Color.parseColor("#E6050A13")
        canvas.drawCircle(cx, cy, r, fill)
        ring.color = c
        ring.alpha = 255
        canvas.drawCircle(cx, cy, r, ring)
        ring.alpha = 160
        val box = RectF(cx - r * .72f, cy - r * .72f, cx + r * .72f, cy + r * .72f)
        canvas.drawArc(box, angle, 70f, false, ring)
        canvas.drawArc(box, angle + 180f, 70f, false, ring)
        fill.color = c
        fill.alpha = 70
        canvas.drawCircle(cx, cy, r * .38f, fill)
        fill.alpha = 255
        fill.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .14f, fill)
    }
}

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var orb: OrbView? = null
    private var input: VoiceInput? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (orb == null) addOrb()
        running = true
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Bolinha do JARVIS", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("JARVIS ativo")
            .setContentText("Toque na bolinha para falar")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Desligar", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, notification)
    }

    private fun addOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (68 * resources.displayMetrics.density).toInt()
        val view = OrbView(this)
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - 16
            y = resources.displayMetrics.heightPixels / 3
        }
        input = VoiceInput(this, onText = { text ->
            view.state = 2
            scope.launch {
                Brain.process(this@BubbleService, text)
                view.state = 0
            }
        }, onEnd = { ok -> if (!ok) view.state = 0 })

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var downAt = 0L
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    downAt = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (System.currentTimeMillis() - downAt > 600) {
                            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } else if (!Brain.busy) {
                            view.state = 1
                            input?.start()
                        }
                    }
                    true
                }
                else -> false
            }
        }
        wm.addView(view, params)
        orb = view
    }

    override fun onDestroy() {
        running = false
        orb?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        orb = null
        input?.destroy()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.devai.jarvis.STOP_BUBBLE"
        private const val CHANNEL = "jarvis_bubble"
        private const val NOTIF_ID = 4201

        var running by mutableStateOf(false)

        fun start(ctx: Context): String {
            if (!Settings.canDrawOverlays(ctx)) return "Ative 'Sobrepor outros apps' no painel de permissões."
            if (!Perms.has(ctx, Manifest.permission.RECORD_AUDIO)) return "Conceda a permissão de microfone primeiro."
            ctx.startForegroundService(Intent(ctx, BubbleService::class.java))
            return "Bolinha ativada. Toque nela para falar com o JARVIS."
        }

        fun stop(ctx: Context): String {
            ctx.startService(Intent(ctx, BubbleService::class.java).setAction(ACTION_STOP))
            return "Bolinha desativada."
        }
    }
}
