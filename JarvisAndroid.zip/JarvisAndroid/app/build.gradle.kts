plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val envFile = rootProject.file(".env.local")
val envKey: String = System.getenv("ELEVENLABS_API_KEY")
    ?: envFile.takeIf { it.exists() }
        ?.readLines()
        ?.firstOrNull { it.trim().startsWith("ELEVENLABS_API_KEY=") }
        ?.substringAfter("=")
        ?.trim()
        ?.trim('"')
    ?: ""

android {
    namespace = "com.devai.jarvis"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.devai.jarvis"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
        buildConfigField("String", "ELEVENLABS_API_KEY", "\"$envKey\"")
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
